#!/usr/bin/env bash
# Быстрый запуск без Docker: ./run.sh  (порт 8000, число воркеров = WORKERS, по умолчанию 2)
set -e
cd "$(dirname "$0")"
# Временные файлы загрузок — в оперативной памяти, а не на диске (Linux).
[ -d /dev/shm ] && export TMPDIR="${TMPDIR:-/dev/shm}"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt
exec uvicorn app.main:app --host "${HOST:-127.0.0.1}" --port "${PORT:-8000}" --workers "${WORKERS:-2}" --proxy-headers
