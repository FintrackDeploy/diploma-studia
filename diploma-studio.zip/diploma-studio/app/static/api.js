import {
  getProject as dbGet, putProject, deleteProject as dbDelete, listProjects as dbList,
  putImage, getImage, deleteImage, newProject as makeProject, newId, serial,
  dataUrlToBlob, blobToDataUrl, requestPersistence, onExternalChange,
} from "./store.js";

export const LIMITS = {
  maxRows: 5000,
  batchRows: 100,                      // строк в пачке для «тяжёлых» шаблонов
  batchRowsLight: 250,                 // и для лёгких (≤ 4 Мпикс): меньше повторных загрузок шаблонов
  validateChunk: 500,                  // строк за один запрос проверки
  pdfPartPages: 500,                   // страниц в одном PDF
  partBytes: 150 * 1024 * 1024,        // размер одного скачиваемого файла: держит память вкладки в пределах
  maxTemplates: 20, maxImageMB: 20,
};

// Если проект изменён в другой вкладке, свои записи блокируем, чтобы не затереть чужие изменения.
const stale = new Set();
const STALE_MSG = "Этот проект изменён в другой вкладке. Обновите страницу (F5), иначе изменения затрут друг друга.";
onExternalChange((id) => {
  stale.add(id);
  if (typeof window !== "undefined" && window.dispatchEvent) window.dispatchEvent(new CustomEvent("project-stale", { detail: { id } }));
});

// В браузере адреса относительные; для тестов можно задать globalThis.API_BASE.
const root = () => globalThis.API_BASE || "";
const BASE = () => root() + "/api";

function errorText(j, fallback) {
  const d = j && j.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d)) return d.map((x) => x.msg || String(x)).join("; ");
  return fallback;
}
async function readError(res) {
  let j = null;
  try { j = await res.json(); } catch (_) {}
  const err = new Error(errorText(j, res.status === 413 ? "Файл слишком большой" : (res.statusText || `Ошибка ${res.status}`)));
  err.status = res.status;
  return err;
}
async function req(path, opts = {}) {
  const res = await fetch(BASE() + path, opts);
  if (!res.ok) throw await readError(res);
  return (res.headers.get("content-type") || "").includes("application/json") ? res.json() : res;
}

// Пачки и проверка идемпотентны, поэтому при 429/502/503/504 и обрыве связи просто повторяем.
const RETRY = new Set([429, 502, 503, 504]);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function fetchRetry(url, makeInit) {
  let last;
  for (let attempt = 0; attempt < 4; attempt++) {
    if (attempt) await sleep(globalThis.RETRY_DELAY_MS ?? 2000 * attempt);
    let res;
    try { res = await fetch(url, makeInit()); }
    catch (_) { last = new Error("Нет связи с сервером. Проверьте интернет и повторите."); continue; }
    if (res.ok || !RETRY.has(res.status)) return res;
    last = await readError(res);
  }
  throw last;
}

// Быстрый несекретный хэш (cyrb53) — только для ключа кэша проверки.
function hash53(str) {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return `${str.length}:${4294967296 * (2097151 & h2) + (h1 >>> 0)}`;
}
const validateCache = new Map(); // pid → {key, result}

// ---------------------------------------------------------------- картинки шаблонов в памяти
const blobCache = new Map(); // "pid/tid" → {blob, url}
function remember(pid, tid, blob) {
  const key = `${pid}/${tid}`;
  const old = blobCache.get(key);
  if (old && old.blob === blob) return old;
  if (old) URL.revokeObjectURL(old.url);
  const entry = { blob, url: URL.createObjectURL(blob) };
  blobCache.set(key, entry);
  return entry;
}
async function hydrate(p) {
  for (const t of p.templates) {
    let entry = blobCache.get(`${p.id}/${t.id}`);
    if (!entry) {
      const blob = await getImage(p.id, t.id);
      if (!blob) throw new Error(`В браузере нет изображения шаблона «${t.name}»`);
      entry = remember(p.id, t.id, blob);
    }
    t._blob = entry.blob; t._url = entry.url;
  }
  return p;
}

async function normalizeImage(file) {
  if (!/^image\/(png|jpe?g)$/i.test(file.type) && !/\.(png|jpe?g)$/i.test(file.name || "")) {
    throw new Error("Поддерживаются только PNG и JPG");
  }
  if (file.size > LIMITS.maxImageMB * 1024 * 1024) throw new Error(`Файл больше ${LIMITS.maxImageMB} МБ`);
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((resolve, reject) => {
      const i = new Image(); i.onload = () => resolve(i); i.onerror = () => reject(new Error("Не удалось прочитать изображение")); i.src = url;
    });
    let w = img.naturalWidth, h = img.naturalHeight;
    const scale = Math.min(1, 4000 / Math.max(w, h));
    const isJpeg = /jpe?g/i.test(file.type) || /\.jpe?g$/i.test(file.name || "");
    if (scale === 1) return { blob: file.type ? file : new Blob([file], { type: isJpeg ? "image/jpeg" : "image/png" }), w, h };
    w = Math.max(1, Math.round(w * scale)); h = Math.max(1, Math.round(h * scale));
    const canvas = document.createElement("canvas"); canvas.width = w; canvas.height = h;
    canvas.getContext("2d").drawImage(img, 0, 0, w, h);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, isJpeg ? "image/jpeg" : "image/png", 0.95));
    if (!blob) throw new Error("Не удалось подготовить изображение");
    return { blob, w, h };
  } finally { URL.revokeObjectURL(url); }
}

// ---------------------------------------------------------------- выбор шаблона (как на сервере)
const normKey = (s) => String(s ?? "").trim().toLowerCase().replaceAll("ё", "е").replace(/\s+/g, " ").replace(/^[ .,:;]+|[ .,:;]+$/g, "");
export function pickTemplate(project, row) {
  const t = project.templates;
  if (!t.length) return null;
  if (t.length === 1) return t[0];
  if (!project.match_column) return null;
  const key = normKey(row[project.match_column]);
  if (!key) return null;
  const index = new Map();
  for (const tpl of t) for (const m of [...(tpl.match || []), tpl.name]) if (normKey(m)) index.set(normKey(m), tpl);
  return index.get(key) || null;
}

function projectPayload(p, rows) {
  return JSON.stringify({
    name: p.name, filename_pattern: p.filename_pattern, match_column: p.match_column,
    columns: p.columns, rows,
    templates: p.templates.map((t) => JSON.parse(JSON.stringify(t, (k, v) => (k.startsWith("_") ? undefined : v)))),
  });
}

// Отправляем только те шаблоны, которые нужны для этих строк (иначе — все: сервер сам назовёт причину).
function buildForm(p, rows, start) {
  const used = new Map();
  let all = false;
  for (const r of rows) { const t = pickTemplate(p, r); if (t) used.set(t.id, t); else all = true; }
  const tpls = all || !used.size ? p.templates : p.templates.filter((t) => used.has(t.id));
  const q = { ...p, templates: tpls };
  const fd = new FormData();
  fd.set("project", new Blob([projectPayload(q, rows)], { type: "application/json" }), "project.json");
  fd.set("start", String(start));
  for (const t of tpls) fd.append("template_files", t._blob, `${t.id}.png`);
  return fd;
}

async function postBatch(kind, p, rows, start) {
  const res = await fetchRetry(`${BASE()}/generate/${kind}`, () => ({ method: "POST", body: buildForm(p, rows, start) }));
  if (!res.ok) throw await readError(res);
  return { buf: await res.arrayBuffer(), problems: Number(res.headers.get("X-Problem-Rows") || 0) };
}

// Переименование колонки переносит все ссылки на неё: поля шаблонов, колонку выбора шаблона, имя файла.
export function applyColumnRename(p, oldName, newName) {
  p.columns = (p.columns || []).map((c) => (c === oldName ? newName : c));
  for (const r of p.rows || []) if (oldName in r) { r[newName] = r[oldName]; delete r[oldName]; }
  if (p.match_column === oldName) p.match_column = newName;
  if (p.filename_pattern) p.filename_pattern = p.filename_pattern.split(`{${oldName}}`).join(`{${newName}}`);
  for (const t of p.templates || []) for (const g of t.groups || []) for (const f of g.fields || []) {
    const src = f.source;
    if (src && Array.isArray(src.columns)) src.columns = src.columns.map((c) => (c === oldName ? newName : c));
  }
}

const safeName = (s) => String(s || "project").replace(/[\\/:*?"<>|\r\n\t]+/g, "_").trim().slice(0, 100) || "project";

export function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

async function updateProjectRecord(pid, mutate) {
  return serial(async () => {
    if (stale.has(pid)) throw new Error(STALE_MSG);
    const p = await dbGet(pid); if (!p) throw new Error("Проект не найден");
    const out = await mutate(p);
    p.updated_at = Date.now();
    await putProject(p);
    return out === undefined ? p : out;
  });
}

export const api = {
  gallery: () => req("/gallery"),
  ensurePersistent: requestPersistence,

  async projectFromGallery(id) {
    const items = await this.gallery();
    const item = items.find((g) => g.id === id);
    if (!item) throw new Error("Такого набора нет в галерее");
    const proj = makeProject(item.title);
    proj.columns = structuredClone(item.columns || []);
    proj.rows = structuredClone(item.rows || []);
    proj.match_column = item.match_column || null;
    proj.filename_pattern = item.filename_pattern || "{n}";
    proj.templates = [];
    const blobs = [];
    for (const t of item.templates) {
      const res = await fetch(`${root()}/gallery-files/${encodeURIComponent(t.image)}?v=${item.rev || 0}`);
      if (!res.ok) throw new Error(`Не удалось загрузить шаблон «${t.name}»`);
      const { image, ...meta } = structuredClone(t);
      proj.templates.push(meta); blobs.push([meta.id, await res.blob()]);
    }
    await serial(async () => {
      for (const [tid, blob] of blobs) await putImage(proj.id, tid, blob);
      await putProject(proj);
    });
    return proj;
  },

  async newProject(name) { const p = makeProject(name); await serial(() => putProject(p)); return p; },
  async getProject(pid) { const p = await dbGet(pid); return p ? hydrate(p) : null; },
  async listProjects() {
    return (await dbList()).map((p) => ({ id: p.id, name: p.name, updated_at: p.updated_at || p.created_at || 0,
      templates: (p.templates || []).length, rows: (p.rows || []).length }))
      .sort((a, b) => b.updated_at - a.updated_at);
  },
  updateProject: (pid, patch) => updateProjectRecord(pid, (p) => { Object.assign(p, patch); }),
  async deleteProject(pid) {
    await serial(() => dbDelete(pid));
    for (const key of [...blobCache.keys()]) if (key.startsWith(`${pid}/`)) { URL.revokeObjectURL(blobCache.get(key).url); blobCache.delete(key); }
    return { ok: true };
  },

  async uploadTemplate(pid, name, file) {
    const n = await normalizeImage(file);
    const tid = newId().slice(0, 8);
    let rec;
    await updateProjectRecord(pid, async (p) => {
      if (p.templates.length >= LIMITS.maxTemplates) throw new Error(`Не больше ${LIMITS.maxTemplates} шаблонов в проекте`);
      await putImage(pid, tid, n.blob);
      rec = { id: tid, name, w: n.w, h: n.h, match: [name], groups: [] };
      p.templates.push(rec);
    });
    const entry = remember(pid, tid, n.blob);
    return { ...rec, _blob: entry.blob, _url: entry.url };
  },
  updateTemplate: (pid, tid, patch) => updateProjectRecord(pid, (p) => {
    const tpl = p.templates.find((t) => t.id === tid); if (!tpl) throw new Error("Шаблон не найден");
    Object.assign(tpl, JSON.parse(JSON.stringify(patch, (k, v) => (k.startsWith("_") ? undefined : v))));
    return tpl;
  }),
  async deleteTemplate(pid, tid) {
    await updateProjectRecord(pid, async (p) => { p.templates = p.templates.filter((t) => t.id !== tid); await deleteImage(pid, tid); });
    const e = blobCache.get(`${pid}/${tid}`); if (e) { URL.revokeObjectURL(e.url); blobCache.delete(`${pid}/${tid}`); }
    return { ok: true };
  },

  uploadRows(_pid, file) {
    const fd = new FormData(); fd.set("file", file);
    return req("/parse-excel", { method: "POST", body: fd });
  },
  renameColumn: (pid, oldName, newName) => updateProjectRecord(pid, (p) => { applyColumnRename(p, oldName, newName); }),
  setRows: (pid, columns, rows) => updateProjectRecord(pid, (p) => { p.columns = columns; p.rows = rows; }).then(() => ({ ok: true })),

  // Проверка идёт пачками по validateChunk строк (прогресс, нет длинных запросов) и кэшируется:
  // пока таблица и настройки не менялись, повторное открытие экрана не гоняет сервер.
  async validate(pid, onProgress = () => {}) {
    const p = await dbGet(pid); if (!p) throw new Error("Проект не найден");
    const total = p.rows.length;
    if (!total) return { total_rows: 0, problems: [], config_errors: [] };
    const key = hash53(projectPayload(p, p.rows));
    const hit = validateCache.get(pid);
    if (hit && hit.key === key) return hit.result;
    const problems = [], cfg = new Set();
    for (let s = 0; s < total; s += LIMITS.validateChunk) {
      onProgress(s, total);
      const body = projectPayload(p, p.rows.slice(s, s + LIMITS.validateChunk));
      const res = await fetchRetry(`${BASE()}/validate`, () => ({ method: "POST", headers: { "Content-Type": "application/json" }, body }));
      if (!res.ok) throw await readError(res);
      const part = await res.json();
      for (const x of part.problems) problems.push({ ...x, row: x.row + s });
      for (const m of part.config_errors || []) cfg.add(m);
    }
    onProgress(total, total);
    const result = { total_rows: total, problems, config_errors: [...cfg] };
    validateCache.set(pid, { key, result });
    return result;
  },

  // Ориентировочный размер результата: нужен, чтобы заранее предупредить о многофайловой выдаче.
  estimate(p, format) {
    let bytes = 0;
    for (const row of p.rows) {
      const t = pickTemplate(p, row); if (!t) continue;
      const px = (t.w || 0) * (t.h || 0);
      const isPng = !t._blob || !t._blob.type || /png/i.test(t._blob.type);
      bytes += format === "pdf" ? px * 0.4 : (isPng && t._blob ? t._blob.size * 1.15 : px * 1.8);
    }
    let files = Math.max(1, Math.ceil(bytes / LIMITS.partBytes));
    if (format === "pdf") files = Math.max(files, Math.ceil(p.rows.length / LIMITS.pdfPartPages));
    return { bytes, files };
  },

  async preview(pid, index) {
    const p = await this.getProject(pid); if (!p) throw new Error("Проект не найден");
    const row = p.rows[index]; if (!row) throw new Error("Такой строки нет");
    return fetch(`${BASE()}/render/preview`, { method: "POST", body: buildForm(p, [row], index + 1) });
  },

  // Генерация пачками: нет лимитов на размер запроса и таймаутов прокси, виден прогресс.
  // Результат выдаётся файлами по мере готовности (onFile), чтобы память вкладки не росла вместе с
  // проектом: когда накоплено LIMITS.partBytes (ZIP) или pdfPartPages страниц (PDF), часть отдаётся
  // и освобождается. Без onFile файлы собираются в массив files (так проще в тестах).
  // Возвращает {files, count, problems}; count — сколько файлов выдано.
  async generate(pid, format, onProgress = () => {}, onFile = null) {
    const p = await this.getProject(pid); if (!p) throw new Error("Проект не найден");
    const rows = p.rows, total = rows.length;
    if (!total) throw new Error("Нет данных для генерации");
    if (total > LIMITS.maxRows) throw new Error(`Слишком много строк: максимум ${LIMITS.maxRows}`);
    const base = safeName(p.name), ext = format === "zip" ? "zip" : "pdf";
    const maxPx = Math.max(0, ...p.templates.map((t) => (t.w || 0) * (t.h || 0)));
    const batch = maxPx && maxPx <= 4_000_000 ? LIMITS.batchRowsLight : LIMITS.batchRows;
    const files = []; let count = 0, part = 1, problems = 0;
    // Если файл один, суффикса нет; если частей несколько — «_часть1», «_часть2»…
    const emit = async (blob, last) => {
      const filename = part === 1 && last ? `${base}.${ext}` : `${base}_часть${part}.${ext}`;
      part++; count++;
      if (onFile) await onFile({ blob, filename }); else files.push({ blob, filename });
    };

    if (format === "zip") {
      let out = new JSZip(), bytes = 0; const used = new Set();
      for (let s = 0; s < total; s += batch) {
        onProgress(s, total);
        const r = await postBatch("zip", p, rows.slice(s, s + batch), s + 1);
        problems += r.problems;
        const zip = await JSZip.loadAsync(r.buf);
        for (const name of Object.keys(zip.files)) {
          if (zip.files[name].dir) continue;
          const stem = name.replace(/\.png$/i, "").replace(/^\d+__/, "");
          // Windows и macOS не различают регистр, поэтому «Иванов» и «иванов» — это один файл.
          let final = stem, k = 2;
          while (used.has(final.toLowerCase())) final = `${stem}_${k++}`;
          used.add(final.toLowerCase());
          const data = await zip.files[name].async("uint8array");
          bytes += data.length;
          out.file(`${final}.png`, data, { compression: "STORE" });
        }
        if (bytes >= LIMITS.partBytes && s + batch < total) {
          await emit(await out.generateAsync({ type: "blob", compression: "STORE" }), false);
          out = new JSZip(); bytes = 0;
        }
      }
      onProgress(total, total);
      await emit(await out.generateAsync({ type: "blob", compression: "STORE" }), true);
      return { files, count, problems };
    }

    // PDF: пачки склеиваются в браузере; часть закрывается по числу страниц или по размеру.
    let doc = await PDFLib.PDFDocument.create(), pages = 0, bytes = 0;
    for (let s = 0; s < total; s += batch) {
      onProgress(s, total);
      const r = await postBatch("pdf", p, rows.slice(s, s + batch), s + 1);
      problems += r.problems; bytes += r.buf.byteLength;
      const src = await PDFLib.PDFDocument.load(r.buf);
      for (const page of await doc.copyPages(src, src.getPageIndices())) { doc.addPage(page); pages++; }
      if ((pages >= LIMITS.pdfPartPages || bytes >= LIMITS.partBytes) && s + batch < total) {
        await emit(new Blob([await doc.save()], { type: "application/pdf" }), false);
        doc = await PDFLib.PDFDocument.create(); pages = 0; bytes = 0;
      }
    }
    onProgress(total, total);
    await emit(new Blob([await doc.save()], { type: "application/pdf" }), true);
    return { files, count, problems };
  },

  async exportProject(pid) {
    const p = await this.getProject(pid); if (!p) throw new Error("Проект не найден");
    const rec = JSON.parse(JSON.stringify(p, (k, v) => (k.startsWith("_") ? undefined : v)));
    for (const t of rec.templates) t.image_data = await blobToDataUrl(p.templates.find((x) => x.id === t.id)._blob);
    saveBlob(new Blob([JSON.stringify(rec)], { type: "application/json" }), `${safeName(p.name)}.diploma.json`);
  },

  async importProject(file) {
    let p;
    try { p = JSON.parse(await file.text()); } catch (_) { throw new Error("Файл проекта повреждён или имеет неверный формат"); }
    if (!p || !Array.isArray(p.templates) || !Array.isArray(p.rows)) throw new Error("Это не файл проекта Мастерской дипломов");
    if (p.rows.length > LIMITS.maxRows) throw new Error(`В проекте больше ${LIMITS.maxRows} строк`);
    if (p.templates.length > LIMITS.maxTemplates) throw new Error(`В проекте больше ${LIMITS.maxTemplates} шаблонов`);
    const pid = newId();
    const blobs = [];
    const seen = new Set();
    for (const t of p.templates) {
      if (!t || typeof t.id !== "string" || !/^[A-Za-z0-9_-]{1,64}$/.test(t.id) || seen.has(t.id)) throw new Error("Файл проекта повреждён: неверные шаблоны");
      if (!t.image_data) throw new Error(`В файле нет изображения шаблона «${t.name || t.id}»`);
      seen.add(t.id);
      try { blobs.push([t.id, dataUrlToBlob(t.image_data)]); } catch (_) { throw new Error(`Не удалось прочитать изображение шаблона «${t.name || t.id}»`); }
      delete t.image_data;
      t.name = String(t.name || "Шаблон"); t.match = Array.isArray(t.match) ? t.match.map(String) : [t.name];
      t.groups = Array.isArray(t.groups) ? t.groups : [];
      for (const g of t.groups) g.fields = Array.isArray(g.fields) ? g.fields : [];
      t.w = Number(t.w) || 0; t.h = Number(t.h) || 0;
    }
    const rec = { ...makeProject(String(p.name || "Проект")), id: pid, templates: p.templates,
      columns: Array.isArray(p.columns) ? p.columns.map(String) : [], rows: p.rows,
      match_column: typeof p.match_column === "string" ? p.match_column : null,
      filename_pattern: typeof p.filename_pattern === "string" ? p.filename_pattern : "{n}" };
    await serial(async () => {
      try { for (const [tid, b] of blobs) await putImage(pid, tid, b); await putProject(rec); }
      catch (e) { await dbDelete(pid).catch(() => {}); throw e; }
    });
    return rec;
  },
  templateImageUrl: (_pid, tpl) => tpl._url,
};
