// Локальное хранилище проектов (IndexedDB).
// Проект (JSON) и картинки шаблонов лежат в разных хранилищах: правка поля или ячейки таблицы
// больше не перезаписывает мегабайты изображений. Все записи идут через одну очередь,
// поэтому параллельные «прочитал → изменил → записал» не затирают друг друга.

const DB_NAME = "diploma-studio";
const DB_VERSION = 2;
const PROJECTS = "projects";
const IMAGES = "images"; // ключ: `${projectId}/${templateId}` → Blob

export function dataUrlToBlob(dataUrl) {
  const [meta, body] = String(dataUrl).split(",", 2);
  if (!meta || body === undefined) throw new Error("Повреждённое изображение");
  const mime = (meta.match(/data:([^;]+)/) || [])[1] || "application/octet-stream";
  const bin = atob(body);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

export function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

let dbPromise = null;
function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (ev) => {
      const db = req.result;
      const t = req.transaction;
      if (!db.objectStoreNames.contains(PROJECTS)) db.createObjectStore(PROJECTS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(IMAGES)) db.createObjectStore(IMAGES);
      if (ev.oldVersion >= 1 && ev.oldVersion < 2) {
        // миграция v1 → v2: картинки из base64 внутри проекта — в отдельное хранилище Blob
        const ps = t.objectStore(PROJECTS), is = t.objectStore(IMAGES);
        ps.openCursor().onsuccess = (e) => {
          const c = e.target.result;
          if (!c) return;
          const p = c.value;
          let changed = false;
          for (const tpl of p.templates || []) {
            if (tpl.image_data) {
              try { is.put(dataUrlToBlob(tpl.image_data), `${p.id}/${tpl.id}`); } catch (_) { /* пропускаем битую */ }
              delete tpl.image_data;
              changed = true;
            }
          }
          if (changed) c.update(p);
          c.continue();
        };
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };
    req.onerror = () => { dbPromise = null; reject(req.error || new Error("Не удалось открыть локальное хранилище")); };
    req.onblocked = () => { /* другая вкладка со старой версией — ждём */ };
  });
  return dbPromise;
}

async function tx(names, mode, fn) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    let t, out;
    try {
      t = db.transaction(names, mode);
      out = fn(t);
    } catch (err) { try { t && t.abort(); } catch (_) {} reject(err); return; }
    t.oncomplete = () => resolve(out && typeof out === "object" && "readyState" in out ? out.result : out);
    t.onerror = () => reject(t.error || new Error("Ошибка локального хранилища"));
    t.onabort = () => reject(t.error || new Error("Операция с локальным хранилищем отменена"));
  });
}

// Очередь: одна запись за раз.
let chain = Promise.resolve();
export function serial(fn) {
  const p = chain.then(fn);
  chain = p.catch(() => {});
  return p;
}

// Поля, начинающиеся с «_» (например _url, _blob), живут только в памяти и не сохраняются.
const stripRuntime = (k, v) => (k.startsWith("_") ? undefined : v);

// Если один проект открыт в двух вкладках, запись из одной затёрла бы изменения другой.
// Поэтому вкладка, записавшая проект, сообщает об этом остальным; те блокируют свои записи (см. api.js).
let channel = null;
try {
  if (typeof BroadcastChannel !== "undefined") {
    channel = new BroadcastChannel("diploma-studio");
    if (channel.unref) channel.unref();   // Node: не держать процесс открытым
  }
} catch (_) { channel = null; }
function announce(id) { try { if (channel) channel.postMessage({ type: "changed", id }); } catch (_) {} }
export function onExternalChange(cb) {
  if (channel) channel.onmessage = (ev) => { if (ev.data && ev.data.type === "changed") cb(ev.data.id); };
}

export function putProject(project) {
  const rec = JSON.parse(JSON.stringify(project, stripRuntime));
  return tx(PROJECTS, "readwrite", (t) => { t.objectStore(PROJECTS).put(rec); return project; })
    .then((r) => { announce(project.id); return r; });
}
export function getProject(id) {
  return tx(PROJECTS, "readonly", (t) => t.objectStore(PROJECTS).get(id)).then((p) => p || null);
}
export function listProjects() {
  return tx(PROJECTS, "readonly", (t) => t.objectStore(PROJECTS).getAll()).then((l) => l || []);
}
export function deleteProject(id) {
  return tx([PROJECTS, IMAGES], "readwrite", (t) => {
    t.objectStore(PROJECTS).delete(id);
    t.objectStore(IMAGES).delete(IDBKeyRange.bound(`${id}/`, `${id}/\uffff`));
  }).then((r) => { announce(id); return r; });
}

export function putImage(pid, tid, blob) {
  return tx(IMAGES, "readwrite", (t) => { t.objectStore(IMAGES).put(blob, `${pid}/${tid}`); });
}
export function getImage(pid, tid) {
  return tx(IMAGES, "readonly", (t) => t.objectStore(IMAGES).get(`${pid}/${tid}`)).then((b) => b || null);
}
export function deleteImage(pid, tid) {
  return tx(IMAGES, "readwrite", (t) => { t.objectStore(IMAGES).delete(`${pid}/${tid}`); });
}

export function newId() {
  return crypto.randomUUID ? crypto.randomUUID().replaceAll("-", "").slice(0, 12) : Math.random().toString(36).slice(2, 14);
}

export function newProject(name = "Новый проект") {
  const now = Date.now();
  return {
    id: newId(), name: name || "Новый проект",
    templates: [], columns: [], rows: [], match_column: null, filename_pattern: "{n}",
    created_at: now, updated_at: now, local_only: true,
  };
}

// Просим браузер не выселять данные при нехватке места (Safari иначе чистит их примерно через 7 дней).
export async function requestPersistence() {
  try {
    if (!navigator.storage || !navigator.storage.persist) return null;
    if (await navigator.storage.persisted()) return true;
    return await navigator.storage.persist();
  } catch (_) { return null; }
}
