import { api, LIMITS, applyColumnRename } from "./api.js";
import { el, icon, btn, confirmDialog, dropZone, plural } from "./ui.js";

const PAGE = 100; // строк на странице таблицы: тысячи полей ввода сразу тормозят браузер

export function renderDataView(mount, state, ctx) {
  const { toast } = ctx;
  const proj = state.project;
  if (!Array.isArray(proj.columns)) proj.columns = [];
  if (!Array.isArray(proj.rows)) proj.rows = [];

  let saveTimer = null, saveInFlight = false, saveAgain = false;
  async function saveNow() {
    if (saveInFlight) { saveAgain = true; return; }
    saveInFlight = true;
    try { await api.setRows(state.pid, proj.columns, proj.rows); }
    catch (e) { toast("Не удалось сохранить таблицу: " + e.message, "err"); }
    finally { saveInFlight = false; if (saveAgain) { saveAgain = false; saveNow(); } }
  }
  function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 150); }

  // Не теряем правки при закрытии/сворачивании вкладки. Слушатели снимаются, когда экран ушёл из DOM.
  function flush() {
    if (!mount.isConnected) {
      document.removeEventListener("visibilitychange", onHidden);
      window.removeEventListener("pagehide", flush);
      return;
    }
    clearTimeout(saveTimer); saveNow();
  }
  function onHidden() { if (document.visibilityState === "hidden") flush(); }
  document.addEventListener("visibilitychange", onHidden);
  window.addEventListener("pagehide", flush);

  let page = 0, query = "";

  async function loadFile(file) {
    if (!file) return;
    if (!/\.xlsx$/i.test(file.name)) { toast("Нужен файл Excel в формате .xlsx", "err"); return; }
    try {
      const res = await api.uploadRows(state.pid, file);
      if (proj.rows.length) {
        const ok = await confirmDialog({
          title: "Заменить таблицу?",
          text: `Текущая таблица (${proj.rows.length} ${plural(proj.rows.length, "строка", "строки", "строк")}) будет заменена данными из файла (${res.rows.length} ${plural(res.rows.length, "строка", "строки", "строк")}).`,
          ok: "Заменить", danger: true,
        });
        if (!ok) return;
      }
      proj.columns = res.columns; proj.rows = res.rows;
      await api.setRows(state.pid, proj.columns, proj.rows);
      toast(`Загружено строк: ${res.rows.length}`);
      page = 0; query = ""; searchInput.value = ""; draw();
    } catch (err) { toast(err.message, "err"); }
  }

  const fileInput = el("input", { type: "file", accept: ".xlsx", style: "display:none", onchange: (e) => { const f = e.target.files[0]; e.target.value = ""; loadFile(f); } });
  const searchInput = el("input", {
    class: "input search", type: "search", placeholder: "Найти в таблице", "aria-label": "Поиск по таблице",
    oninput: (e) => { query = e.target.value.trim().toLowerCase(); page = 0; drawTable(); },
  });
  const counter = el("span", { class: "pill" });

  const toolbar = el("div", { class: "data-toolbar" }, [
    btn("Загрузить Excel", { cls: "btn brass", ico: "upload", onclick: () => fileInput.click() }), fileInput,
    btn("Колонка", { cls: "btn secondary", ico: "plus", onclick: addColumn }),
    btn("Строка", { cls: "btn secondary", ico: "plus", onclick: addRow }),
    el("div", { class: "spacer" }),
    el("div", { class: "search-wrap", html: icon("search") }, searchInput),
    counter,
  ]);
  const tip = el("p", { class: "tip", html: icon("info") + "<span>Можно вставить данные из Excel прямо в ячейку (Ctrl+V) — таблица сама расширится. Перетащите .xlsx на таблицу, чтобы загрузить файл.</span>" });
  const holder = el("div", { class: "table-zone" });
  mount.appendChild(toolbar); mount.appendChild(tip); mount.appendChild(holder);
  dropZone(holder, loadFile);

  function addColumn() {
    let n = 1, name;
    do { name = `Колонка ${n++}`; } while (proj.columns.includes(name));
    proj.columns.push(name);
    proj.rows.forEach((r) => { r[name] = ""; });
    scheduleSave(); draw();
  }
  function addRow() {
    if (!proj.columns.length) addColumnSilently();
    if (proj.rows.length >= LIMITS.maxRows) { toast(`Максимум ${LIMITS.maxRows} строк`, "err"); return; }
    const row = {};
    proj.columns.forEach((c) => { row[c] = ""; });
    proj.rows.push(row);
    query = ""; searchInput.value = "";
    page = Math.floor((proj.rows.length - 1) / PAGE);
    scheduleSave(); draw();
    holder.querySelector("tbody tr:last-child .cell-in")?.focus();
  }
  async function renameColumn(oldName, newName) {
    if (!newName || newName === oldName) return;
    if (proj.columns.includes(newName)) { toast("Такая колонка уже есть", "err"); draw(); return; }
    applyColumnRename(proj, oldName, newName);   // в памяти: проект, таблица, поля шаблонов
    scheduleSave();
    try { await api.renameColumn(state.pid, oldName, newName); }
    catch (e) { toast("Не удалось сохранить: " + e.message, "err"); }
    draw();
  }
  async function deleteColumn(name) {
    const used = proj.templates.some((t) => (t.groups || []).some((g) => g.fields.some((f) => f.source.type === "column" && f.source.columns.includes(name))));
    const ok = await confirmDialog({
      title: `Удалить колонку «${name}»?`,
      text: used ? "Эта колонка используется в полях бланков — они останутся без данных, пока вы не выберете другую колонку." : "Значения этой колонки во всех строках будут удалены.",
      ok: "Удалить", danger: true,
    });
    if (!ok) return;
    proj.columns = proj.columns.filter((c) => c !== name);
    proj.rows.forEach((r) => { delete r[name]; });
    if (proj.match_column === name) proj.match_column = null;
    scheduleSave(); draw();
  }
  function deleteRow(idx) { proj.rows.splice(idx, 1); scheduleSave(); drawTable(); }

  function addColumnSilently() {
    let n = 1, name;
    do { name = `Колонка ${n++}`; } while (proj.columns.includes(name));
    proj.columns.push(name);
    proj.rows.forEach((r) => { r[name] = ""; });
  }
  function pasteGrid(startRow, startCol, text) {
    const grid = text.replace(/\r/g, "").split("\n");
    while (grid.length && grid[grid.length - 1] === "") grid.pop();
    const rowsData = grid.map((line) => line.split("\t"));
    const neededCols = startCol + Math.max(...rowsData.map((r) => r.length));
    while (proj.columns.length < neededCols) addColumnSilently();
    const neededRows = startRow + rowsData.length;
    if (neededRows > LIMITS.maxRows) { toast(`Максимум ${LIMITS.maxRows} строк`, "err"); return; }
    while (proj.rows.length < neededRows) { const row = {}; proj.columns.forEach((c) => { row[c] = ""; }); proj.rows.push(row); }
    rowsData.forEach((cells, ri) => cells.forEach((val, ci) => { proj.rows[startRow + ri][proj.columns[startCol + ci]] = val; }));
    scheduleSave(); draw();
    toast(`Вставлено строк: ${rowsData.length}`);
  }

  function draw() {
    const has = proj.columns.length > 0;
    tip.style.display = toolbar.querySelector(".search-wrap").style.display = counter.style.display = has ? "" : "none";
    if (!has) {
      holder.innerHTML = "";
      holder.appendChild(el("div", { class: "empty big dropzone", onclick: () => fileInput.click() }, [
        el("span", { class: "dz-ico", html: icon("table", "lg") }),
        el("h4", {}, "Добавьте список получателей"),
        el("p", { class: "hint" }, "Перетащите сюда файл Excel (.xlsx) — первая строка станет названиями колонок. Или соберите таблицу вручную."),
        el("div", { class: "row-btns" }, [
          btn("Выбрать файл Excel", { cls: "btn brass", ico: "upload" }),
          btn("Ввести вручную", { cls: "btn secondary", ico: "plus", onclick: (e) => { e.stopPropagation(); proj.columns = ["ФИО"]; proj.rows = [{ "ФИО": "" }]; scheduleSave(); draw(); } }),
        ]),
      ]));
      return;
    }
    drawTable();
  }

  function drawTable() {
    holder.innerHTML = "";
    const visible = [];
    for (let i = 0; i < proj.rows.length; i++) {
      if (!query || proj.columns.some((c) => String(proj.rows[i][c] ?? "").toLowerCase().includes(query))) visible.push(i);
    }
    counter.textContent = query ? `Найдено ${visible.length} из ${proj.rows.length}` : `${proj.rows.length} ${plural(proj.rows.length, "строка", "строки", "строк")} · ${proj.columns.length} ${plural(proj.columns.length, "колонка", "колонки", "колонок")}`;

    const pages = Math.max(1, Math.ceil(visible.length / PAGE));
    page = Math.min(page, pages - 1);
    const from = page * PAGE, to = Math.min(visible.length, from + PAGE);

    const table = el("table", { class: "data-table" });
    table.appendChild(el("thead", {}, el("tr", {}, [
      el("th", { class: "rownum" }, "№"),
      ...proj.columns.map((c) => el("th", {}, el("div", { class: "col-head" }, [
        el("input", { class: "cell-in head-in", value: c, "aria-label": "Название колонки", onchange: (e) => renameColumn(c, e.target.value.trim() || c) }),
        el("button", { class: "btn ghost icon sm", title: "Удалить колонку", "aria-label": "Удалить колонку " + c, html: icon("x"), onclick: () => deleteColumn(c) }),
      ]))),
    ])));
    const tbody = el("tbody");
    if (!visible.length) {
      tbody.appendChild(el("tr", {}, el("td", { colspan: String(proj.columns.length + 1), class: "none" }, query ? "Ничего не найдено" : "В таблице пока нет строк — нажмите «Строка» или вставьте данные из Excel")));
    }
    visible.slice(from, to).forEach((ri) => {
      const row = proj.rows[ri];
      tbody.appendChild(el("tr", {}, [
        el("td", { class: "rownum" }, [
          el("span", { class: "rn" }, String(ri + 1)),
          el("button", { class: "rowdel", title: "Удалить строку", "aria-label": "Удалить строку " + (ri + 1), html: icon("x"), onclick: () => deleteRow(ri) }),
        ]),
        ...proj.columns.map((c, ci) => el("td", {}, el("input", {
          class: "cell-in", value: row[c] ?? "", "aria-label": c,
          oninput: (e) => { row[c] = e.target.value; scheduleSave(); },
          onpaste: (e) => {
            const text = (e.clipboardData || window.clipboardData).getData("text");
            if (text.includes("\t") || text.includes("\n")) { e.preventDefault(); pasteGrid(ri, ci, text); }
          },
        }))),
      ]));
    });
    table.appendChild(tbody);
    holder.appendChild(el("div", { class: "table-scroll" }, table));

    if (pages > 1) {
      const go = (n) => { page = Math.max(0, Math.min(pages - 1, n)); drawTable(); holder.scrollIntoView({ block: "start" }); };
      holder.appendChild(el("div", { class: "pager" }, [
        btn("Назад", { cls: "btn secondary sm", ico: "back", onclick: () => go(page - 1), disabled: page === 0 }),
        el("span", {}, `Строки ${from + 1}–${to} из ${visible.length}`),
        (() => { const b = btn("Дальше", { cls: "btn secondary sm", onclick: () => go(page + 1), disabled: page === pages - 1 }); b.insertAdjacentHTML("beforeend", icon("next")); return b; })(),
      ]));
    }
  }

  draw();
}
