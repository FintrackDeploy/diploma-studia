import { api } from "./api.js";
import { el, icon, btn, sealSvg, guilloche, confirmDialog, plural } from "./ui.js";
import { renderTemplatesView } from "./view_templates.js";
import { renderDataView } from "./view_data.js";
import { renderPreviewView } from "./view_preview.js";
import { renderExportView } from "./view_export.js";

export { el };
const root = document.getElementById("root");
const toastsEl = document.getElementById("toasts");

export function toast(msg, level = "ok") {
  const node = el("div", { class: "toast" + (level === "err" ? " err" : ""), role: level === "err" ? "alert" : "status" }, [
    el("span", { html: icon(level === "err" ? "alert" : "check") }), el("span", {}, msg),
  ]);
  toastsEl.appendChild(node);
  setTimeout(() => node.remove(), level === "err" ? 5600 : 3400);
}

// Один и тот же проект открыт в другой вкладке и там изменён: эта вкладка больше не пишет в хранилище.
window.addEventListener("project-stale", (ev) => {
  if (!ev.detail || ev.detail.id !== state.pid || document.getElementById("stale-banner")) return;
  const banner = el("div", { id: "stale-banner", class: "stale-banner", role: "alert" }, [
    el("span", { html: icon("alert") }),
    el("span", {}, "Этот проект изменён в другой вкладке. Чтобы не затереть изменения, обновите страницу."),
    el("button", { class: "btn sm brass", onclick: () => location.reload() }, "Обновить"),
  ]);
  document.body.prepend(banner);
});

const state = { pid: null, project: null, step: "templates" };
function parseHash() {
  const m = location.hash.match(/^#\/p\/([a-z0-9]+)(?:\/(\w+))?/);
  if (m) return { pid: m[1], step: m[2] || "templates" };
  return { pid: null, step: null };
}

async function route() {
  const { pid, step } = parseHash();
  window.scrollTo(0, 0);
  if (!pid) {
    state.pid = null; state.project = null;
    document.title = "Мастерская дипломов";
    await renderHome();
    return;
  }
  state.step = step || "templates";
  if (state.pid !== pid) {
    state.pid = pid;
    try {
      state.project = await api.getProject(pid);
    } catch (e) {
      toast("Не удалось открыть проект: " + e.message, "err");
      state.pid = null; location.hash = ""; return;
    }
    if (!state.project) {
      toast("Проект не найден в локальном хранилище этого браузера", "err");
      state.pid = null; location.hash = ""; return;
    }
  }
  renderProject();
}
window.addEventListener("hashchange", route);

const fmtDate = (ts) => new Date(ts).toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

// ---------------------------------------------------------------- главная

async function renderHome() {
  root.innerHTML = "";
  const page = el("div", { class: "home" });

  page.appendChild(el("header", { class: "home-top" }, [
    el("div", { class: "brand", html: sealSvg(34) + '<div><b>Мастерская <i>дипломов</i></b><small>бланки · грамоты · сертификаты</small></div>' }),
    el("nav", { class: "home-nav" }, [
      el("a", { class: "home-link", href: "/privacy.html", html: icon("shield") + "<span>Приватность</span>" }),
    ]),
  ]));

  const hero = el("section", { class: "hero" }, [
    el("div", { class: "hero-copy" }, [
      el("div", { class: "eyebrow" }, [el("span", { class: "eyebrow-dot" }), el("span", {}, "ПЕЧАТНЫЕ ДОКУМЕНТЫ БЕЗ РУЧНОЙ РАБОТЫ")]),
      el("h1", {}, "Один бланк. Сотни готовых дипломов."),
      el("p", { class: "lead" }, "Подставьте данные из Excel в ваш фирменный бланк — и за несколько минут получите аккуратную серию PDF или PNG, готовую к печати."),
      el("div", { class: "hero-actions" }, [
        btn("Начать с бланка", { cls: "btn lg brass hero-primary", ico: "plus", onclick: onCreateBlank }),
        btn("Посмотреть готовые наборы", { cls: "btn lg secondary", ico: "layers", onclick: () => document.getElementById("gallery")?.scrollIntoView({ behavior: "smooth", block: "start" }) }),
        btn("Загрузить проект", { cls: "btn lg ghost hero-import", ico: "upload", onclick: onImportProject, title: "Открыть ранее скачанный файл проекта" }),
      ]),
      el("div", { class: "hero-trust" }, [
        el("span", { html: icon("check") + "Без регистрации" }),
        el("span", { html: icon("check") + "PDF · PNG · ZIP" }),
        el("span", { html: icon("check") + "Данные не хранятся на сервере" }),
      ]),
      el("p", { class: "hero-note", id: "retention-hint", html: icon("shield") + "<span></span>" }),
    ]),
    el("div", { class: "hero-art", "aria-hidden": "true" }, [
      el("div", { class: "rosette", html: guilloche({ size: 520, layers: 4, R: 100, r: 37, d: 62, step: 6, stroke: "#c9a24a", sw: .5, opacity: .9 }) }),
      el("div", { class: "rosette r2", html: guilloche({ size: 520, layers: 3, R: 100, r: 41, d: 48, step: 8, stroke: "#8fa6d6", sw: .45, opacity: .55 }) }),
      el("img", { class: "mini-diploma-image", src: "/hero-diploma.png", alt: "Пример грамоты с полем ФИО" }),
    ]),
  ]);
  page.appendChild(hero);

  page.appendChild(el("section", { id: "how-it-works", class: "how-section" }, [
    el("div", { class: "section-kicker" }, "ПРОСТОЙ СЦЕНАРИЙ"),
    el("div", { class: "how-head" }, [
      el("h2", {}, "От бланка до готовых файлов — за три шага"),
      el("p", { class: "hint" }, "Никакой ручной подстановки фамилий и копирования страниц."),
    ]),
    el("div", { class: "how-grid" }, [
      howCard("01", "Загрузите бланк", "PDF, PNG или JPG. Ваш дизайн остаётся вашим.", "upload"),
      howCard("02", "Свяжите поля", "Покажите, где должны оказаться ФИО, класс, место и другие данные.", "layers"),
      howCard("03", "Получите серию", "Добавьте Excel и скачайте готовые дипломы одним архивом.", "download"),
    ]),
  ]));

  page.appendChild(el("section", { id: "gallery", class: "gallery-section" }, [
    sectionHead("Готовые наборы", "Выберите пример, чтобы сразу увидеть рабочий проект с бланком и таблицей."),
    el("div", { id: "gallery-grid", class: "gallery-grid" }, [1, 2, 3].map(() => el("div", { class: "gallery-card skeleton" }))),
  ]));

  page.appendChild(sectionHead("Ваши проекты", "Хранятся только в этом браузере"));
  page.appendChild(el("div", { id: "recents-grid", class: "recents" }));

  root.appendChild(page);

  renderRecents();
  const hintEl = () => document.querySelector("#retention-hint span");
  hintEl().textContent = "Проекты хранятся только в вашем браузере. Для проверки и генерации сервер получает шаблоны и таблицу на время запроса и не сохраняет их.";
  api.ensurePersistent().then((ok) => {
    const h = hintEl();
    if (h && ok === false) h.textContent += " Браузер может очистить данные при нехватке места — периодически нажимайте «Сохранить копию».";
  });

  try {
    const items = await api.gallery();
    const grid = document.getElementById("gallery-grid");
    if (!grid) return;
    grid.innerHTML = "";
    items.forEach((g) => grid.appendChild(galleryCard(g)));
  } catch (e) {
    const grid = document.getElementById("gallery-grid");
    if (grid) { grid.innerHTML = ""; grid.appendChild(el("div", { class: "empty" }, [el("h4", {}, "Не удалось загрузить наборы"), el("p", { class: "hint" }, "Обновите страницу. Проект можно создать и без готового набора.")])); }
  }
}

function howCard(num, title, text, ico) {
  return el("article", { class: "how-card" }, [
    el("div", { class: "how-num" }, num),
    el("div", { class: "how-icon", html: icon(ico) }),
    el("h3", {}, title),
    el("p", {}, text),
  ]);
}

function sectionHead(title, sub) {
  return el("div", { class: "section-head" }, [el("h2", {}, title), el("p", { class: "hint" }, sub)]);
}

async function renderRecents() {
  const grid = document.getElementById("recents-grid");
  let list = [];
  try { list = await api.listProjects(); } catch (e) { toast("Не удалось прочитать список проектов: " + e.message, "err"); }
  if (!grid || !grid.isConnected) return;
  grid.innerHTML = "";
  if (!list.length) {
    grid.appendChild(el("div", { class: "empty" }, [
      el("h4", {}, "Пока ничего нет"),
      el("p", { class: "hint" }, "Начните с готового набора выше или создайте пустой проект со своим бланком."),
    ]));
    return;
  }
  list.sort((a, b) => (b.updated_at || 0) - (a.updated_at || 0));
  list.forEach((r) => {
    const open = () => { location.hash = `#/p/${r.id}/templates`; };
    grid.appendChild(el("div", { class: "recent", role: "link", tabindex: "0", onclick: open, onkeydown: (e) => { if (e.key === "Enter") open(); } }, [
      el("div", { class: "stamp", "aria-hidden": "true" }, [el("span", {}, Array.from((r.name || "?").trim())[0].toUpperCase())]),
      el("div", { class: "recent-main" }, [
        el("b", {}, r.name || "Без названия"),
        el("span", { class: "hint" }, `${r.templates} ${plural(r.templates, "шаблон", "шаблона", "шаблонов")} · ${r.rows} ${plural(r.rows, "строка", "строки", "строк")}`),
      ]),
      el("span", { class: "hint recent-date" }, "Изменён " + fmtDate(r.updated_at)),
      el("button", {
        class: "btn ghost icon sm", title: "Удалить проект", "aria-label": "Удалить проект", html: icon("trash"),
        onclick: async (e) => {
          e.stopPropagation();
          const ok = await confirmDialog({ title: `Удалить «${r.name}»?`, text: "Проект исчезнет из этого браузера. Если нужна копия, сначала откройте проект и нажмите «Сохранить копию».", ok: "Удалить", danger: true });
          if (!ok) return;
          try { await api.deleteProject(r.id); } catch (err) { toast(err.message, "err"); }
          renderRecents();
        },
      }),
    ]));
  });
}

function galleryCard(g) {
  const thumbs = g.thumbs.slice(0, 4);
  const card = el("div", { class: "gallery-card" + (g.templates.length > 1 ? " feat" : ""), role: "button", tabindex: "0", onclick: () => use(), onkeydown: (e) => { if (e.key === "Enter") use(); } }, [
    el("div", { class: "g-stage" }, thumbs.map((t, i) => el("img", { src: `/gallery-files/${t}?v=${g.rev || 0}`, alt: "", class: "gp gp" + i + " n" + thumbs.length, loading: "lazy" }))),
    el("div", { class: "g-body" }, [
      el("h3", {}, g.title),
      el("p", { class: "hint" }, g.description),
      el("div", { class: "g-meta" }, [
        el("span", { class: "pill" }, `${g.templates.length} ${plural(g.templates.length, "шаблон", "шаблона", "шаблонов")}`),
        el("span", { class: "pill" }, `${g.rows.length} ${plural(g.rows.length, "строка", "строки", "строк")} примера`),
        el("span", { class: "g-go", html: "Открыть" + icon("next") }),
      ]),
    ]),
  ]);
  async function use() {
    if (card.classList.contains("busy")) return;
    card.classList.add("busy");
    try {
      const proj = await api.projectFromGallery(g.id);
      toast(`Проект «${g.title}» создан`);
      location.hash = `#/p/${proj.id}/templates`;
    } catch (e) { toast(e.message, "err"); card.classList.remove("busy"); }
  }
  return card;
}

async function onCreateBlank() {
  try {
    const proj = await api.newProject("Новый проект");
    location.hash = `#/p/${proj.id}/templates`;
  } catch (e) { toast(e.message, "err"); }
}

async function onImportProject() {
  const input = document.createElement("input");
  input.type = "file"; input.accept = ".json,.diploma.json,application/json";
  input.onchange = async () => {
    const file = input.files[0]; if (!file) return;
    try {
      const proj = await api.importProject(file);
      toast("Проект открыт и сохранён в этом браузере");
      location.hash = `#/p/${proj.id}/templates`;
    } catch (e) { toast(e.message, "err"); }
  };
  input.click();
}

// ---------------------------------------------------------------- экран проекта

const STEPS = [
  { id: "templates", label: "Бланки и поля", ico: "layers", meta: (p) => (p.templates.length ? `${p.templates.length} ${plural(p.templates.length, "бланк", "бланка", "бланков")}` : "добавьте бланк"), done: (p) => p.templates.length > 0 },
  { id: "data", label: "Таблица", ico: "table", meta: (p) => (p.rows.length ? `${p.rows.length} ${plural(p.rows.length, "строка", "строки", "строк")}` : "добавьте данные"), done: (p) => p.rows.length > 0 },
  { id: "preview", label: "Предпросмотр", ico: "eye", meta: () => "проверьте глазами", done: () => false },
  { id: "export", label: "Экспорт", ico: "download", meta: () => "ZIP или PDF", done: () => false },
];

export async function refreshProject() {
  state.project = await api.getProject(state.pid);
  if (!state.project) throw new Error("Проект не найден в этом браузере");
  return state.project;
}
export function getState() { return state; }

function renderProject() {
  root.innerHTML = "";
  const proj = state.project;
  document.title = `${proj.name} — Мастерская дипломов`;

  const nameInput = el("input", {
    class: "proj-name", value: proj.name, "aria-label": "Название проекта", spellcheck: "false",
    onchange: async (e) => {
      const name = e.target.value.trim() || "Без названия";
      e.target.value = name;
      try { await api.updateProject(state.pid, { name }); proj.name = name; document.title = `${name} — Мастерская дипломов`; }
      catch (err) { toast("Не удалось сохранить название: " + err.message, "err"); }
    },
    onkeydown: (e) => { if (e.key === "Enter") e.target.blur(); },
  });

  const topbar = el("header", { class: "topbar" }, [
    el("a", { class: "brand compact", href: "#", title: "Все проекты", onclick: (e) => { e.preventDefault(); location.hash = ""; }, html: sealSvg(30) }),
    el("a", { class: "crumb", href: "#", onclick: (e) => { e.preventDefault(); location.hash = ""; }, html: icon("back") + "<span>Проекты</span>" }),
    el("span", { class: "crumb-sep" }, "/"),
    nameInput,
    el("div", { class: "spacer" }),
    el("span", { class: "save-state", title: "Проект хранится в IndexedDB этого браузера", html: '<i class="dot"></i><span>Сохранено в браузере</span>' }),
    btn("Сохранить копию", { cls: "btn secondary sm save-copy", title: "Сохранить копию проекта", ico: "save", onclick: () => api.exportProject(state.pid).then(() => toast("Копия проекта скачана")).catch((e) => toast(e.message, "err")) }),
    el("button", {
      class: "btn ghost icon sm", title: "Удалить проект", "aria-label": "Удалить проект", html: icon("trash"),
      onclick: async () => {
        const ok = await confirmDialog({ title: "Удалить проект?", text: "Проект исчезнет из этого браузера. Если нужна копия, сначала нажмите «Сохранить копию».", ok: "Удалить", danger: true });
        if (!ok) return;
        try { await api.deleteProject(state.pid); } catch (err) { toast(err.message, "err"); return; }
        location.hash = "";
      },
    }),
  ]);

  const stepper = el("nav", { class: "stepper", "aria-label": "Шаги проекта" }, STEPS.map((s, i) => {
    const active = state.step === s.id;
    const done = s.done(proj);
    return el("a", {
      class: "step" + (active ? " active" : "") + (done ? " done" : ""), href: `#/p/${state.pid}/${s.id}`,
      "aria-current": active ? "step" : null,
    }, [
      el("span", { class: "step-n", html: done && !active ? icon("check") : String(i + 1) }),
      el("span", { class: "step-t" }, [el("b", {}, s.label), el("small", {}, s.meta(proj))]),
    ]);
  }));

  const view = el("main", { class: "view view-" + state.step, id: "view-body" });
  root.appendChild(el("div", { class: "shell" }, [topbar, stepper, view]));

  const ctx = { toast, el, refreshProject, rerender: renderProject };
  if (state.step === "templates") renderTemplatesView(view, state, ctx);
  else if (state.step === "data") renderDataView(view, state, ctx);
  else if (state.step === "preview") renderPreviewView(view, state, ctx);
  else renderExportView(view, state, ctx);
}

route();
