import { sealSvg } from "./ui.js";
const brand = document.getElementById("pv-brand");
if (brand) brand.insertAdjacentHTML("afterbegin", sealSvg(34));
