import { api } from "./api.js";
import { el, icon, btn, confirmDialog, dropZone, plural } from "./ui.js";

const FAMILIES = ["Liberation Serif", "Liberation Sans", "DejaVu Serif"];

function uid(prefix) { return prefix + Math.random().toString(36).slice(2, 8); }

function emptyField(n) {
  return {
    id: uid("f"), name: `Поле ${n}`,
    source: { type: "column", columns: [], join: "\n" },
    part: "all", transform: "none",
    font: { family: "Liberation Serif", bold: true, color: "#000000" },
    size_max: 40, size_min: 14, line_gap: 4, gap_after: 0,
    align: "center", fill: false, stretch_x: false, max_height_pct: null, required: false,
  };
}
function emptyGroup(n, tplW, tplH) {
  const w = tplW * 0.6, h = tplH * 0.22;
  return {
    id: uid("g"), name: `Область ${n}`,
    zone: [(tplW - w) / 2, (tplH - h) / 2, (tplW + w) / 2, (tplH + h) / 2],
    valign: 0.5, halo: 0,
    fields: [emptyField(1)],
  };
}

const opt = (value, label, cur) => el("option", { value, selected: String(cur) === String(value) ? "" : null }, label);
function select(options, cur, onchange) {
  return el("select", { onchange: (e) => onchange(e.target.value) }, options.map(([v, l]) => opt(v, l, cur)));
}
function labeled(label, control, cls = "") { return el("div", { class: "field " + cls }, [el("label", {}, label), control]); }
function num(label, value, onChange) {
  return labeled(label, el("input", { type: "number", value: String(value ?? ""), min: "0", onchange: (e) => onChange(parseFloat(e.target.value) || 0) }));
}
function sw(label, checked, onchange) {
  const input = el("input", { type: "checkbox", checked: checked ? "" : null, onchange: (e) => onchange(e.target.checked) });
  return el("label", { class: "switch" }, [input, el("span", { class: "track" }), el("span", {}, label)]);
}

export function renderTemplatesView(mount, state, ctx) {
  const { toast } = ctx;
  const proj = state.project;
  let selectedTplId = proj.templates[0] ? proj.templates[0].id : null;
  let selectedGroupId = null;
  const openFields = new Set();

  const wrap = el("div", { class: "tpl-layout" });
  mount.appendChild(wrap);
  const rail = el("aside", { class: "tpl-rail" });
  const workspace = el("div", { class: "tpl-work" });
  wrap.appendChild(rail);
  wrap.appendChild(workspace);

  function persistTemplate(tpl) {
    return api.updateTemplate(state.pid, tpl.id, { name: tpl.name, match: tpl.match, groups: tpl.groups })
      .catch((e) => toast("Не удалось сохранить бланк: " + e.message, "err"));
  }
  const currentTpl = () => proj.templates.find((t) => t.id === selectedTplId);

  // ------------------------------------------------------------ левая колонка: список бланков
  function drawRail() {
    rail.innerHTML = "";
    rail.appendChild(el("div", { class: "rail-title" }, [el("h3", {}, "Бланки"), el("span", { class: "pill" }, String(proj.templates.length))]));
    const list = el("div", { class: "tpl-list" });
    proj.templates.forEach((t) => {
      const fields = (t.groups || []).reduce((n, g) => n + g.fields.length, 0);
      list.appendChild(el("button", {
        class: "tpl-item" + (t.id === selectedTplId ? " active" : ""), type: "button",
        onclick: () => { selectedTplId = t.id; selectedGroupId = null; drawRail(); drawWorkspace(); },
      }, [
        el("img", { src: api.templateImageUrl(state.pid, t), alt: "" }),
        el("span", { class: "tmeta" }, [
          el("b", {}, t.name),
          el("small", {}, `${fields} ${plural(fields, "поле", "поля", "полей")}`),
        ]),
      ]));
    });
    rail.appendChild(list);
    rail.appendChild(btn("Добавить бланк", { cls: "btn secondary sm tpl-add", ico: "plus", onclick: () => openUploadDialog() }));

    if (proj.templates.length > 1) {
      const warn = !proj.match_column;
      rail.appendChild(el("div", { class: "match-card" + (warn ? " warn" : "") }, [
        el("h4", {}, "Как выбрать бланк для строки"),
        el("p", { class: "hint" }, "Укажите колонку таблицы, по значению которой подбирается бланк: оно должно совпасть с названием бланка или с одним из его значений сопоставления."),
        el("div", { class: "field" }, [
          el("label", {}, "Колонка типа"),
          el("select", {
            onchange: async (e) => {
              proj.match_column = e.target.value || null;
              try { await api.updateProject(state.pid, { match_column: proj.match_column }); }
              catch (err) { toast("Не удалось сохранить: " + err.message, "err"); }
              drawRail();
            },
          }, [opt("", "— не выбрана —", proj.match_column || ""), ...proj.columns.map((c) => opt(c, c, proj.match_column))]),
        ]),
        warn ? el("p", { class: "match-warn", html: icon("alert") + "<span>Без колонки типа экспорт при нескольких бланках невозможен.</span>" }) : null,
      ]));
    }
  }

  // ------------------------------------------------------------ загрузка бланка
  function openUploadDialog(preFile) {
    const nameInput = el("input", { type: "text", value: `Бланк ${proj.templates.length + 1}` });
    let nameTouched = false;
    nameInput.addEventListener("input", () => { nameTouched = true; });
    const fileInput = el("input", { type: "file", accept: ".png,.jpg,.jpeg", style: "display:none" });
    const preview = el("img", { class: "up-preview", alt: "" });
    const dz = el("div", { class: "dropzone", tabindex: "0", role: "button", onclick: () => fileInput.click(), onkeydown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileInput.click(); } } }, [
      el("span", { class: "dz-ico", html: icon("image", "lg") }),
      el("b", {}, "Перетащите файл или нажмите, чтобы выбрать"),
      el("span", { class: "hint" }, "PNG или JPG. Для чёткой печати A4 лучше около 2480×3508 px."),
    ]);
    let file = null;
    function setFile(f) {
      if (!f) return;
      if (!/\.(png|jpe?g)$/i.test(f.name)) { toast("Нужен файл PNG или JPG", "err"); return; }
      file = f;
      if (!nameTouched) nameInput.value = f.name.replace(/\.[^.]+$/, "").slice(0, 60) || nameInput.value;
      preview.src = URL.createObjectURL(f);
      dz.classList.add("has");
      dz.querySelector("b").textContent = f.name;
    }
    fileInput.addEventListener("change", () => setFile(fileInput.files[0]));
    dropZone(dz, setFile);
    dz.prepend(preview);

    const done = () => { document.removeEventListener("keydown", onKey); modal.remove(); };
    const onKey = (e) => { if (e.key === "Escape") done(); };
    const submit = btn("Загрузить бланк", { cls: "btn brass", onclick: async () => {
      if (!file) { toast("Выберите файл бланка", "err"); return; }
      submit.disabled = true; submit.insertAdjacentHTML("afterbegin", '<span class="spin"></span>');
      try {
        const tpl = await api.uploadTemplate(state.pid, nameInput.value.trim() || "Бланк", file);
        proj.templates.push(tpl);
        selectedTplId = tpl.id; selectedGroupId = null;
        done(); drawRail(); drawWorkspace();
        toast("Бланк загружен — отметьте на нём области текста");
      } catch (e) { toast(e.message, "err"); submit.disabled = false; submit.querySelector(".spin")?.remove(); }
    } });
    const modal = el("div", { class: "modal-veil", onclick: (e) => { if (e.target === modal) done(); } }, [
      el("div", { class: "modal", role: "dialog", "aria-modal": "true" }, [
        el("h3", {}, "Новый бланк"),
        dz, fileInput,
        labeled("Название бланка", nameInput),
        el("p", { class: "hint" }, "Название нужно, чтобы сопоставить бланк со значением в колонке «Тип», если бланков несколько."),
        el("div", { class: "modal-actions" }, [el("button", { class: "btn secondary", onclick: done }, "Отмена"), submit]),
      ]),
    ]);
    document.addEventListener("keydown", onKey);
    document.body.appendChild(modal);
    if (preFile) setFile(preFile);
  }

  // ------------------------------------------------------------ рабочая область
  function drawWorkspace() {
    workspace.innerHTML = "";
    const tpl = currentTpl();
    if (!tpl) {
      const dz = el("div", { class: "empty big dropzone", onclick: () => openUploadDialog() }, [
        el("span", { class: "dz-ico", html: icon("image", "lg") }),
        el("h4", {}, "Начните с бланка"),
        el("p", { class: "hint" }, "Перетащите сюда картинку грамоты, диплома или сертификата (PNG или JPG) — или нажмите, чтобы выбрать файл. Затем отметьте на ней, где будет текст."),
        btn("Выбрать файл", { cls: "btn brass", ico: "upload" }),
      ]);
      dropZone(dz, (f) => openUploadDialog(f));
      workspace.appendChild(dz);
      return;
    }
    if (!Array.isArray(tpl.groups)) tpl.groups = [];
    if (!selectedGroupId && tpl.groups[0]) selectedGroupId = tpl.groups[0].id;

    // --- сцена
    const stage = el("section", { class: "stage" });
    const head = el("div", { class: "stage-head" }, [
      el("input", {
        class: "tpl-name", type: "text", value: tpl.name, "aria-label": "Название бланка",
        onchange: (e) => { tpl.name = e.target.value.trim() || "Бланк"; e.target.value = tpl.name; persistTemplate(tpl); drawRail(); },
        onkeydown: (e) => { if (e.key === "Enter") e.target.blur(); },
      }),
      el("div", { class: "spacer" }),
      btn("Удалить бланк", { cls: "btn ghost sm danger-text", ico: "trash", onclick: async () => {
        const ok = await confirmDialog({ title: `Удалить бланк «${tpl.name}»?`, text: "Вместе с ним удалятся все его области и поля.", ok: "Удалить", danger: true });
        if (!ok) return;
        try { await api.deleteTemplate(state.pid, tpl.id); } catch (err) { toast(err.message, "err"); return; }
        proj.templates = proj.templates.filter((t) => t.id !== tpl.id);
        selectedTplId = proj.templates[0] ? proj.templates[0].id : null; selectedGroupId = null;
        drawRail(); drawWorkspace();
      } }),
    ]);
    const frame = el("div", { class: "canvas-frame" });
    const img = el("img", { class: "bg", src: api.templateImageUrl(state.pid, tpl), alt: "Бланк «" + tpl.name + "»", draggable: "false" });
    frame.appendChild(img);
    stage.appendChild(head);
    stage.appendChild(el("div", { class: "desk" }, frame));
    stage.appendChild(el("p", { class: "stage-hint", html: icon("info") + "<span>Тяните рамку за середину, чтобы переместить, и за уголки — чтобы изменить размер. Рамка выбранной области сдвигается стрелками (Shift — крупнее).</span>" }));
    if (proj.templates.length > 1) {
      const match = el("input", {
        type: "text", value: (tpl.match || []).join(", "), placeholder: "например: Грамота, Диплом I степени",
        onchange: (e) => { tpl.match = e.target.value.split(",").map((s) => s.trim()).filter(Boolean); persistTemplate(tpl); },
      });
      stage.appendChild(el("div", { class: "field match-values" }, [
        el("label", {}, "Значения колонки типа, которые ведут на этот бланк"), match,
        el("span", { class: "hint" }, "Через запятую. Если пусто — подходит значение, равное названию бланка."),
      ]));
    }
    workspace.appendChild(stage);

    // --- инспектор
    const inspector = el("aside", { class: "inspector" });
    workspace.appendChild(inspector);

    function renderZones() {
      frame.querySelectorAll(".zone-rect").forEach((n) => n.remove());
      tpl.groups.forEach((g, i) => {
        const rect = el("div", {
          class: "zone-rect" + (g.id === selectedGroupId ? " sel" : ""), "data-gid": g.id, tabindex: "0",
          style: zoneStyle(g.zone, tpl) + `--zc:var(--g${i % 4});`, "aria-label": "Область «" + g.name + "»",
        }, [
          el("div", { class: "zlabel" }, g.name),
          el("div", { class: "zfields" }, g.fields.map((f) => el("span", {}, f.name))),
          el("i", { class: "handle nw" }), el("i", { class: "handle ne" }), el("i", { class: "handle sw" }), el("i", { class: "handle se" }),
        ]);
        wireDrag(rect, frame, tpl, g, () => persistTemplate(tpl));
        rect.addEventListener("pointerdown", () => selectGroup(g.id, true), true);
        rect.addEventListener("focus", () => selectGroup(g.id, false));
        frame.appendChild(rect);
      });
    }

    function selectGroup(id, scroll) {
      if (selectedGroupId === id) return;
      selectedGroupId = id;
      frame.querySelectorAll(".zone-rect").forEach((r) => r.classList.toggle("sel", r.dataset.gid === id));
      inspector.querySelectorAll(".group-card").forEach((c) => {
        const on = c.dataset.gid === id;
        c.classList.toggle("open", on);
        if (on && scroll) c.scrollIntoView({ block: "nearest", behavior: "smooth" });
      });
    }

    function renderInspector() {
      const keepScroll = inspector.scrollTop;
      inspector.innerHTML = "";
      inspector.appendChild(el("div", { class: "insp-head" }, [
        el("div", {}, [el("h3", {}, "Области текста"), el("p", { class: "hint" }, "Каждая область — рамка на бланке, куда встанет текст из таблицы.")]),
        btn("Область", { cls: "btn brass sm", ico: "plus", onclick: () => {
          const g = emptyGroup(tpl.groups.length + 1, tpl.w, tpl.h);
          tpl.groups.push(g); selectedGroupId = g.id; openFields.add(g.fields[0].id);
          persistTemplate(tpl); renderZones(); renderInspector();
          setTimeout(() => inspector.querySelector(".group-card.open")?.scrollIntoView({ block: "nearest", behavior: "smooth" }), 30);
        } }),
      ]));
      if (!tpl.groups.length) {
        inspector.appendChild(el("div", { class: "empty" }, [el("h4", {}, "Областей пока нет"), el("p", { class: "hint" }, "Добавьте область и перетащите рамку на то место бланка, где должен стоять текст.")]));
      }
      tpl.groups.forEach((g, i) => inspector.appendChild(groupCard(g, i)));
      inspector.scrollTop = keepScroll;
    }

    function groupCard(g, i) {
      const card = el("div", { class: "group-card" + (g.id === selectedGroupId ? " open" : ""), "data-gid": g.id, style: `--zc:var(--g${i % 4})` });
      const head = el("div", { class: "group-head", onclick: (e) => { if (e.target.closest("input,button")) return; selectGroup(card.classList.contains("open") ? null : g.id, false); } }, [
        el("i", { class: "gdot" }),
        el("input", { value: g.name, "aria-label": "Название области", onfocus: () => selectGroup(g.id, false), onchange: (e) => { g.name = e.target.value.trim() || g.name; persistTemplate(tpl); renderZones(); } }),
        el("span", { class: "hint gcount" }, `${g.fields.length} ${plural(g.fields.length, "поле", "поля", "полей")}`),
        el("button", { class: "btn ghost icon sm", title: "Удалить область", "aria-label": "Удалить область", html: icon("trash"), onclick: async () => {
          const ok = await confirmDialog({ title: `Удалить область «${g.name}»?`, text: "Рамка и все поля внутри неё будут удалены.", ok: "Удалить", danger: true });
          if (!ok) return;
          tpl.groups = tpl.groups.filter((x) => x.id !== g.id);
          if (selectedGroupId === g.id) selectedGroupId = tpl.groups[0] ? tpl.groups[0].id : null;
          persistTemplate(tpl); renderZones(); renderInspector();
        } }),
        el("span", { class: "chev", html: icon("down") }),
      ]);
      const body = el("div", { class: "group-body" });
      body.appendChild(el("div", { class: "group-opts" }, [
        labeled("Положение текста в рамке", select([["0", "Сверху"], ["0.5", "По центру"], ["1", "Снизу"]], g.valign, (v) => { g.valign = parseFloat(v); persistTemplate(tpl); })),
        labeled("Осветлить фон под текстом", el("input", {
          type: "range", min: "0", max: "255", value: String(g.halo || 0),
          oninput: (e) => { g.halo = parseInt(e.target.value, 10); }, onchange: () => persistTemplate(tpl),
        })),
      ]));
      g.fields.forEach((f) => body.appendChild(fieldCard(g, f)));
      body.appendChild(btn("Добавить поле", { cls: "btn secondary sm add-field", ico: "plus", onclick: () => {
        const f = emptyField(g.fields.length + 1); g.fields.push(f); openFields.add(f.id);
        persistTemplate(tpl); renderZones(); renderInspector();
      } }));
      card.appendChild(head); card.appendChild(body);
      return card;
    }

    function fieldCard(g, f) {
      const isColumn = f.source.type === "column";
      const open = openFields.has(f.id);
      const card = el("div", { class: "field-card" + (open ? " open" : "") });

      const cols = isColumn ? f.source.columns : [];
      const summary = isColumn
        ? (cols.length ? cols.map((c) => el("span", { class: "chip on mini" }, c)) : [el("span", { class: "hint warn-text" }, "колонка не выбрана")])
        : [el("span", { class: "hint" }, f.source.value ? "«" + f.source.value.slice(0, 40) + "»" : "текст не задан")];

      card.appendChild(el("div", { class: "fhead", onclick: (e) => { if (e.target.closest("input,button,label")) return; open ? openFields.delete(f.id) : openFields.add(f.id); card.classList.toggle("open"); } }, [
        el("span", { class: "chev", html: icon("down") }),
        el("input", { class: "fname", value: f.name, "aria-label": "Название поля", onchange: (e) => { f.name = e.target.value.trim() || f.name; persistTemplate(tpl); renderZones(); } }),
        el("span", { class: "fsum" }, summary),
        el("button", { class: "btn ghost icon sm", title: "Удалить поле", "aria-label": "Удалить поле", html: icon("x"), onclick: () => {
          g.fields = g.fields.filter((x) => x.id !== f.id); persistTemplate(tpl); renderZones(); renderInspector();
        } }),
      ]));

      const body = el("div", { class: "fbody" });
      body.appendChild(el("div", { class: "fsec" }, [
        el("div", { class: "fsec-t" }, "Откуда берётся текст"),
        el("div", { class: "seg" }, [
          el("button", { type: "button", class: isColumn ? "on" : "", onclick: () => { if (isColumn) return; f.source = { type: "column", columns: [], join: "\n" }; persistTemplate(tpl); renderInspector(); } }, "Из таблицы"),
          el("button", { type: "button", class: !isColumn ? "on" : "", onclick: () => { if (!isColumn) return; f.source = { type: "text", value: "" }; persistTemplate(tpl); renderInspector(); } }, "Один и тот же текст"),
        ]),
        isColumn
          ? el("div", { class: "chips" }, proj.columns.length
              ? proj.columns.map((c) => el("button", { type: "button", class: "chip" + (f.source.columns.includes(c) ? " on" : ""), onclick: () => {
                  const cs = f.source.columns, k = cs.indexOf(c);
                  if (k >= 0) cs.splice(k, 1); else cs.push(c);
                  persistTemplate(tpl); renderInspector();
                } }, c))
              : [el("span", { class: "hint" }, "Сначала добавьте колонки на шаге «Таблица».")])
          : labeled("Текст", el("input", { type: "text", value: f.source.value, onchange: (e) => { f.source.value = e.target.value; persistTemplate(tpl); renderInspector(); } })),
        el("p", { class: "hint" }, "Чтобы перенести слово на новую строку, поставьте в тексте знак | — например: Берестовицкому|району."),
        isColumn && f.source.columns.length > 1
          ? labeled("Соединять колонки через", select([["\n", "перенос строки"], [" ", "пробел"], [", ", "запятую"]], f.source.join, (v) => { f.source.join = v; persistTemplate(tpl); }))
          : null,
        el("div", { class: "frow" }, [
          labeled("Часть ФИО", select([["all", "как есть"], ["surname", "фамилия"], ["given", "имя и отчество"]], f.part, (v) => { f.part = v; persistTemplate(tpl); })),
          labeled("Регистр", select([["none", "без изменений"], ["upper", "ЗАГЛАВНЫЕ"], ["title", "Как В Заголовке"], ["lower", "строчные"]], f.transform, (v) => { f.transform = v; persistTemplate(tpl); })),
        ]),
        sw("Обязательное — без значения строка считается ошибкой", f.required, (v) => { f.required = v; persistTemplate(tpl); }),
      ]));
      body.appendChild(el("div", { class: "fsec" }, [
        el("div", { class: "fsec-t" }, "Шрифт"),
        el("div", { class: "frow" }, [
          labeled("Гарнитура", select(FAMILIES.map((x) => [x, x]), f.font.family, (v) => { f.font.family = v; persistTemplate(tpl); })),
          labeled("Цвет", el("input", { type: "color", value: f.font.color, onchange: (e) => { f.font.color = e.target.value; persistTemplate(tpl); } }), "narrow"),
        ]),
        el("div", { class: "frow" }, [
          num("Размер, макс.", f.size_max, (v) => { f.size_max = v; persistTemplate(tpl); }),
          num("Размер, мин.", f.size_min, (v) => { f.size_min = v; persistTemplate(tpl); }),
        ]),
        el("div", { class: "frow" }, [
          num("Межстрочный", f.line_gap, (v) => { f.line_gap = v; persistTemplate(tpl); }),
          num("Отступ снизу", f.gap_after, (v) => { f.gap_after = v; persistTemplate(tpl); }),
        ]),
        el("div", { class: "frow" }, [
          labeled("Выравнивание", select([["center", "по центру"], ["left", "по левому краю"], ["right", "по правому краю"]], f.align, (v) => { f.align = v; persistTemplate(tpl); })),
        ]),
        el("div", { class: "frow sw-row" }, [
          sw("Жирный", f.font.bold, (v) => { f.font.bold = v; persistTemplate(tpl); }),
          sw("Растянуть текст на всю область", f.fill, (v) => { f.fill = v; persistTemplate(tpl); renderInspector(); }),
          f.fill ? sw("…и по ширине до краёв (буквы станут шире)", f.stretch_x, (v) => { f.stretch_x = v; persistTemplate(tpl); }) : null,
        ]),
      ]));
      card.appendChild(body);
      return card;
    }

    img.addEventListener("load", renderZones);
    if (img.complete) renderZones();
    renderInspector();
  }

  drawRail();
  drawWorkspace();
}

function zoneStyle(zone, tpl) {
  const [x1, y1, x2, y2] = zone;
  const l = (x1 / tpl.w) * 100, t = (y1 / tpl.h) * 100;
  const w = ((x2 - x1) / tpl.w) * 100, h = ((y2 - y1) / tpl.h) * 100;
  return `left:${l}%;top:${t}%;width:${w}%;height:${h}%;`;
}

function wireDrag(rectEl, frameEl, tpl, group, onCommit) {
  const zc = rectEl.getAttribute("style").match(/--zc:[^;]+;/);
  function apply() { rectEl.setAttribute("style", zoneStyle(group.zone, tpl) + (zc ? zc[0] : "")); }

  function startDrag(mode, downEvt) {
    downEvt.preventDefault(); downEvt.stopPropagation();
    rectEl.focus({ preventScroll: true });
    const rectBox = frameEl.getBoundingClientRect();
    const start = { x: downEvt.clientX, y: downEvt.clientY };
    const zone0 = group.zone.slice();
    rectEl.classList.add("dragging");

    function onMove(e) {
      const dx = ((e.clientX - start.x) / rectBox.width) * tpl.w;
      const dy = ((e.clientY - start.y) / rectBox.height) * tpl.h;
      let [x1, y1, x2, y2] = zone0;
      if (mode === "move") {
        const w = x2 - x1, h = y2 - y1;
        x1 = clamp(zone0[0] + dx, 0, tpl.w - w); x2 = x1 + w;
        y1 = clamp(zone0[1] + dy, 0, tpl.h - h); y2 = y1 + h;
      } else {
        if (mode.includes("w")) x1 = clamp(zone0[0] + dx, 0, x2 - 20);
        if (mode.includes("e")) x2 = clamp(zone0[2] + dx, x1 + 20, tpl.w);
        if (mode.includes("n")) y1 = clamp(zone0[1] + dy, 0, y2 - 20);
        if (mode.includes("s")) y2 = clamp(zone0[3] + dy, y1 + 20, tpl.h);
      }
      group.zone = [x1, y1, x2, y2];
      apply();
    }
    function onUp() {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      rectEl.classList.remove("dragging");
      onCommit();
    }
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }

  rectEl.addEventListener("pointerdown", (e) => {
    if (e.target.classList.contains("handle")) return;
    startDrag("move", e);
  });
  rectEl.querySelectorAll(".handle").forEach((h) => {
    const mode = [...h.classList].find((c) => c !== "handle");
    h.addEventListener("pointerdown", (e) => startDrag(mode, e));
  });

  // Клавиатура: стрелки двигают рамку, Alt+стрелки меняют размер
  let t = null;
  rectEl.addEventListener("keydown", (e) => {
    const dir = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
    if (!dir || e.target !== rectEl) return;
    e.preventDefault();
    const k = e.shiftKey ? 0.02 : 0.004;
    const dx = dir[0] * tpl.w * k, dy = dir[1] * tpl.h * k;
    let [x1, y1, x2, y2] = group.zone;
    if (e.altKey) { x2 = clamp(x2 + dx, x1 + 20, tpl.w); y2 = clamp(y2 + dy, y1 + 20, tpl.h); }
    else {
      const w = x2 - x1, h = y2 - y1;
      x1 = clamp(x1 + dx, 0, tpl.w - w); x2 = x1 + w; y1 = clamp(y1 + dy, 0, tpl.h - h); y2 = y1 + h;
    }
    group.zone = [x1, y1, x2, y2]; apply();
    clearTimeout(t); t = setTimeout(onCommit, 400);
  });
}

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }