import { api } from "./api.js";
import { el, icon, btn, plural } from "./ui.js";

export function renderPreviewView(mount, state, ctx) {
  const proj = state.project;
  let index = 0, objectUrl = null, token = 0;

  if (!proj.rows.length || !proj.templates.length) {
    const noRows = !proj.rows.length;
    mount.appendChild(el("div", { class: "empty big" }, [
      el("span", { class: "dz-ico", html: icon(noRows ? "table" : "layers", "lg") }),
      el("h4", {}, noRows ? "Сначала добавьте данные" : "Сначала добавьте бланк"),
      el("p", { class: "hint" }, noRows ? "Когда в таблице появятся строки, здесь можно будет посмотреть, как выглядит каждый документ." : "Загрузите хотя бы один бланк и отметьте на нём области текста."),
      btn(noRows ? "Перейти к таблице" : "Перейти к бланкам", { cls: "btn brass", onclick: () => { location.hash = `#/p/${state.pid}/${noRows ? "data" : "templates"}`; } }),
    ]));
    return;
  }

  const total = proj.rows.length;
  const img = el("img", { alt: "Предпросмотр документа" });
  const sheet = el("div", { class: "sheet loading" }, [img, el("div", { class: "sheet-veil" }, el("span", { class: "spin" }))]);

  const jump = el("input", { class: "input jump", type: "number", min: "1", max: String(total), value: "1", "aria-label": "Номер строки" });
  const prevBtn = btn("", { cls: "btn secondary icon", ico: "back", title: "Предыдущая строка (←)", onclick: () => go(index - 1) });
  const nextBtn = btn("", { cls: "btn secondary icon", ico: "next", title: "Следующая строка (→)", onclick: () => go(index + 1) });
  prevBtn.setAttribute("aria-label", "Предыдущая строка"); nextBtn.setAttribute("aria-label", "Следующая строка");
  jump.addEventListener("change", () => {
    const n = parseInt(jump.value, 10);
    if (n >= 1 && n <= total) go(n - 1); else jump.value = String(index + 1);
  });
  jump.addEventListener("keydown", (e) => { if (e.key === "Enter") jump.blur(); e.stopPropagation(); });

  const nav = el("div", { class: "preview-nav" }, [prevBtn, el("span", { class: "idx" }, ["Строка ", jump, ` из ${total}`]), nextBtn]);
  const stage = el("section", { class: "preview-stage" }, [nav, el("div", { class: "desk" }, sheet)]);

  const status = el("div", { class: "row-status" });
  const dataBox = el("dl", { class: "row-data" });
  const problemsBox = el("div", { class: "problems" });
  const side = el("aside", { class: "preview-side" }, [
    el("div", { class: "side-card" }, [el("h3", {}, "Эта строка"), status, dataBox]),
    el("div", { class: "side-card" }, [el("h3", {}, "Проблемы во всей таблице"), problemsBox]),
  ]);
  mount.appendChild(el("div", { class: "preview-layout" }, [stage, side]));

  // Стрелки на клавиатуре; слушатель снимается, когда экран ушёл из DOM
  function onKey(e) {
    if (!mount.isConnected) { document.removeEventListener("keydown", onKey); return; }
    if (e.target.closest && e.target.closest("input,select,textarea")) return;
    if (e.key === "ArrowLeft") go(index - 1);
    if (e.key === "ArrowRight") go(index + 1);
  }
  document.addEventListener("keydown", onKey);

  function drawRowData() {
    dataBox.innerHTML = "";
    const row = proj.rows[index] || {};
    proj.columns.forEach((c) => {
      const v = String(row[c] ?? "").trim();
      dataBox.appendChild(el("div", {}, [el("dt", {}, c), el("dd", { class: v ? "" : "blank" }, v || "пусто")]));
    });
  }

  async function go(newIndex) {
    if (newIndex < 0 || newIndex >= total) return;
    index = newIndex;
    const my = ++token;
    jump.value = String(index + 1);
    prevBtn.disabled = index === 0; nextBtn.disabled = index === total - 1;
    sheet.classList.add("loading");
    drawRowData();
    status.innerHTML = "";
    try {
      const res = await api.preview(state.pid, index);
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.detail || "Не удалось построить предпросмотр");
      }
      const warnings = JSON.parse(decodeURIComponent(res.headers.get("X-Warnings") || "%5B%5D"));
      const blob = await res.blob();
      if (my !== token) return;   // пока грузилось, пользователь ушёл на другую строку
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      objectUrl = URL.createObjectURL(blob);
      img.src = objectUrl;
      sheet.classList.remove("loading");
      drawWarnings(warnings);
    } catch (e) {
      if (my !== token) return;
      sheet.classList.remove("loading");
      status.appendChild(el("div", { class: "note err", html: icon("alert") }, el("span", {}, e.message)));
    }
  }

  function drawWarnings(warnings) {
    status.innerHTML = "";
    if (!warnings.length) {
      status.appendChild(el("div", { class: "note ok", html: icon("check") }, el("span", {}, "Весь текст поместился")));
      return;
    }
    warnings.forEach((w) => status.appendChild(el("div", { class: "note " + (w.level === "error" ? "err" : "warn"), html: icon("alert") }, el("span", {}, w.msg))));
  }

  async function loadProblems() {
    problemsBox.innerHTML = "";
    problemsBox.appendChild(el("div", { class: "note", html: '<span class="spin"></span>' }, el("span", {}, "Проверяю таблицу…")));
    try {
      const res = await api.validate(state.pid);
      problemsBox.innerHTML = "";
      (res.config_errors || []).forEach((m) => problemsBox.appendChild(el("div", { class: "note err", html: icon("alert") }, el("span", {}, m))));
      if (!res.problems.length) {
        if (!(res.config_errors || []).length) problemsBox.appendChild(el("div", { class: "note ok", html: icon("check") }, el("span", {}, "Проблем не найдено")));
        return;
      }
      const byRow = {};
      res.problems.forEach((p) => { (byRow[p.row] = byRow[p.row] || []).push(p.msg); });
      const rows = Object.entries(byRow);
      problemsBox.appendChild(el("p", { class: "hint" }, `${rows.length} ${plural(rows.length, "строка", "строки", "строк")} с проблемами. Нажмите, чтобы посмотреть.`));
      rows.slice(0, 60).forEach(([rowIdx, msgs]) => {
        problemsBox.appendChild(el("button", { class: "problem", type: "button", onclick: () => go(parseInt(rowIdx, 10)), title: msgs.join("; ") }, [
          el("b", {}, "#" + (parseInt(rowIdx, 10) + 1)),
          el("span", {}, msgs[0] + (msgs.length > 1 ? ` (+${msgs.length - 1})` : "")),
        ]));
      });
      if (rows.length > 60) problemsBox.appendChild(el("p", { class: "hint" }, `…и ещё строк: ${rows.length - 60}`));
    } catch (e) {
      problemsBox.innerHTML = "";
      problemsBox.appendChild(el("div", { class: "note err", html: icon("alert") }, el("span", {}, "Не удалось выполнить проверку.")));
    }
  }

  go(0);
  loadProblems();
}
