// Общие мелочи интерфейса: создание узлов, иконки, гильош, диалоги.

export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined || c === false) continue;
    node.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c);
  }
  return node;
}

// ---------------------------------------------------------------- иконки (контурные, 24×24)
const ICONS = {
  plus: "M12 5v14M5 12h14",
  upload: "M12 16V4m0 0L7 9m5-5 5 5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3",
  download: "M12 4v12m0 0-5-5m5 5 5-5M4 20h16",
  table: "M4 5h16v14H4zM4 10h16M4 15h16M10 5v14",
  eye: "M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  check: "M5 12.5l4.5 4.5L19 7.5",
  x: "M6 6l12 12M18 6 6 18",
  trash: "M4 7h16M10 11v6M14 11v6M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12M9 7V4h6v3",
  back: "M15 5l-7 7 7 7",
  next: "M9 5l7 7-7 7",
  down: "M6 9l6 6 6-6",
  image: "M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9.5h.01",
  layers: "M12 3 3 8l9 5 9-5-9-5zM3 13l9 5 9-5",
  alert: "M12 4 2.5 20h19L12 4zM12 10v4.5M12 17.5h.01",
  save: "M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6",
  folder: "M3 7a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7z",
  file: "M6 3h8l5 5v13H6zM14 3v5h5M9 13h6M9 17h6",
  zip: "M6 3h8l5 5v13H6zM14 3v5h5M11 11h2M11 14h2M11 17h2",
  type: "M5 6V4h14v2M12 4v16M9 20h6",
  move: "M12 3v18M3 12h18M12 3l-3 3m3-3 3 3M12 21l-3-3m3 3 3-3M3 12l3-3m-3 3 3 3M21 12l-3-3m3 3-3 3",
  wand: "M5 19 17 7M14 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2zM19 12l.7 1.3L21 14l-1.3.7L19 16l-.7-1.3L17 14l1.3-.7L19 12z",
  copy: "M8 8h11v12H8zM5 16V4h11",
  info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5M12 8h.01",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3zM9 12l2 2 4-4",
  search: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4",
  more: "M5 12h.01M12 12h.01M19 12h.01",
  home: "M4 11 12 4l8 7v9h-5v-6H9v6H4z",
  list: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
  printer: "M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z",
};
export function icon(name, cls = "") {
  const p = ICONS[name] || "";
  return `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true"><path d="${p}"/></svg>`;
}
export function iconEl(name, cls = "") {
  const s = document.createElement("span");
  s.style.display = "inline-flex";
  s.innerHTML = icon(name, cls);
  return s.firstElementChild;
}
// Кнопка: иконка + подпись
export function btn(label, { cls = "btn", ico, onclick, title, disabled } = {}) {
  const b = el("button", { class: cls, type: "button", title: title || null, onclick, disabled: disabled || null });
  if (ico) b.insertAdjacentHTML("beforeend", icon(ico));
  if (label) b.appendChild(el("span", {}, label));
  return b;
}

// ---------------------------------------------------------------- гильош
// Гипотрохоида: семейство кривых с шагом параметра даёт ту самую «гравированную» розетку.
export function guilloche({ size = 400, layers = 3, R = 100, r = 37, d = 58, step = 7, stroke = "currentColor", sw = 0.45, opacity = 0.85 } = {}) {
  const k = (R - r) / r;
  const reach = (R - r) + d + step * layers;
  const scale = (size / 2 - 2) / reach;
  const turns = r / gcd(R, r);
  const N = Math.round(turns * 72);
  let paths = "";
  for (let L = 0; L < layers; L++) {
    const dd = d + L * step;
    let dstr = "";
    for (let i = 0; i <= N; i++) {
      const t = (i / N) * Math.PI * 2 * turns;
      const x = ((R - r) * Math.cos(t) + dd * Math.cos(k * t)) * scale + size / 2;
      const y = ((R - r) * Math.sin(t) - dd * Math.sin(k * t)) * scale + size / 2;
      dstr += (i ? "L" : "M") + x.toFixed(1) + " " + y.toFixed(1);
    }
    paths += `<path d="${dstr}" />`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" fill="none" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round" opacity="${opacity}" aria-hidden="true">${paths}</svg>`;
}
function gcd(a, b) { return b ? gcd(b, a % b) : a; }

// Логотип: бланк с гравированной шапкой и золотой печатью с лентами
function scallop(cx, cy, r, n = 18, depth = 1.5) {
  let d = "";
  for (let i = 0; i < n * 2; i++) {
    const a = (Math.PI * i) / n - Math.PI / 2, rr = i % 2 ? r - depth : r;
    d += (i ? "L" : "M") + (cx + rr * Math.cos(a)).toFixed(2) + " " + (cy + rr * Math.sin(a)).toFixed(2);
  }
  return d + "Z";
}
export function sealSvg(size = 34) {
  const star = [];
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (Math.PI * i) / 5, r = i % 2 ? 2.1 : 4.7;
    star.push((32 + r * Math.cos(a)).toFixed(2) + "," + (31.5 + r * Math.sin(a)).toFixed(2));
  }
  return `<span class="brand-mark" style="width:${size}px;height:${size}px" aria-hidden="true">
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="48" height="48" rx="13" fill="currentColor"/>
      <rect x="1" y="1" width="46" height="46" rx="12" stroke="#fff" stroke-opacity=".08"/>
      <rect x="8.5" y="7.5" width="25" height="32" rx="2.5" fill="#fffefa"/>
      <rect x="11.5" y="10.5" width="19" height="26" rx="1.2" stroke="#c9a46a" stroke-width=".9"/>
      <path d="M16 16.5h10" stroke="#9a7440" stroke-width="1.7" stroke-linecap="round"/>
      <path d="M15 21.5h12M15 25h12M15 28.5h7" stroke="#b5b8bb" stroke-width="1.3" stroke-linecap="round"/>
      <path d="M27.5 40.5 25 47l4.2-2 2.3 3.2 1.6-7.7z" fill="#7a5a2e"/>
      <path d="M36.5 40.5 39 47l-4.2-2-2.3 3.2-1.6-7.7z" fill="#9a7440"/>
      <path d="${scallop(32, 31.5, 10.5)}" fill="#d2ad6c" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
      <circle cx="32" cy="31.5" r="7.2" fill="currentColor"/>
      <circle cx="32" cy="31.5" r="7.2" stroke="#d2ad6c" stroke-width=".7" stroke-opacity=".9"/>
      <polygon points="${star.join(" ")}" fill="#f0d79c"/>
    </svg>
  </span>`;
}

// ---------------------------------------------------------------- диалоги
export function confirmDialog({ title, text, ok = "Подтвердить", cancel = "Отмена", danger = false }) {
  return new Promise((resolve) => {
    const done = (v) => { document.removeEventListener("keydown", onKey); veil.remove(); resolve(v); };
    const onKey = (e) => { if (e.key === "Escape") done(false); };
    const okBtn = el("button", { class: "btn" + (danger ? " danger" : ""), onclick: () => done(true) }, ok);
    const veil = el("div", { class: "modal-veil", onclick: (e) => { if (e.target === veil) done(false); } }, [
      el("div", { class: "modal", role: "dialog", "aria-modal": "true" }, [
        el("h3", {}, title),
        text ? el("p", { class: "hint", style: "font-size:14px;color:var(--ink-2)" }, text) : null,
        el("div", { class: "modal-actions" }, [el("button", { class: "btn secondary", onclick: () => done(false) }, cancel), okBtn]),
      ]),
    ]);
    document.addEventListener("keydown", onKey);
    document.body.appendChild(veil);
    okBtn.focus();
  });
}

// Зона «перетащите файл сюда»
export function dropZone(node, onFile) {
  const over = (e) => { e.preventDefault(); node.classList.add("drag"); };
  const out = () => node.classList.remove("drag");
  node.addEventListener("dragover", over);
  node.addEventListener("dragenter", over);
  node.addEventListener("dragleave", out);
  node.addEventListener("drop", (e) => {
    e.preventDefault(); out();
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) onFile(f);
  });
}

export function plural(n, one, few, many) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
  return many;
}
