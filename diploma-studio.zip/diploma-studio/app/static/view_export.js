import { api, saveBlob, LIMITS } from "./api.js";
import { el, icon, btn, confirmDialog, plural } from "./ui.js";

export function renderExportView(mount, state, ctx) {
  const { toast } = ctx;
  const proj = state.project;
  const canExport = proj.rows.length > 0 && proj.templates.length > 0;
  const mb = (n) => Math.max(1, Math.round(n / 1048576));

  let busy = false;
  let lastCheck = null; // результат проверки: используем перед скачиванием

  const layout = el("div", { class: "export-layout" });
  const main = el("div", { class: "export-main" });
  const side = el("aside", { class: "export-side" });
  layout.appendChild(main); layout.appendChild(side);
  mount.appendChild(layout);

  // ------------------------------------------------------------ имя файла
  const patternInput = el("input", {
    type: "text", class: "input", value: (proj.filename_pattern || "{n}").replace(/\{n\}/g, "№"), spellcheck: "false", "aria-label": "Шаблон имени файла",
    oninput: updateExample,
    onchange: async (e) => {
      proj.filename_pattern = (e.target.value || "№").replace(/№/g, "{n}");
      try { await api.updateProject(state.pid, { filename_pattern: proj.filename_pattern }); }
      catch (err) { toast("Не удалось сохранить: " + err.message, "err"); }
    },
  });
  const example = el("code", { class: "example" });
  function updateExample() {
    const row = proj.rows[0] || {};
    const name = (patternInput.value || "№").replace(/№|\{([^}]+)\}/g, (m, k) => (!k || k === "n" || k === "№" ? "1" : (row[k] !== undefined && String(row[k]).trim() ? String(row[k]).trim() : m)));
    example.textContent = name + ".png";
  }
  function insertToken(tok) {
    patternInput.value += tok; updateExample();
    patternInput.dispatchEvent(new Event("change")); patternInput.focus();
  }
  const tokens = ["№", ...proj.columns.slice(0, 8).map((c) => `{${c}}`)];
  main.appendChild(el("section", { class: "panel" }, [
    el("div", { class: "panel-head" }, [el("h3", {}, "Имя файла"), el("p", { class: "hint" }, "Каждый документ получит своё имя. № — номер по порядку, остальное — значения колонок.")]),
    patternInput,
    el("div", { class: "chips tokens" }, tokens.map((t) => el("button", { type: "button", class: "chip", onclick: () => insertToken(t), title: "Добавить в имя" }, t))),
    el("p", { class: "hint" }, ["Первый файл будет называться ", example]),
  ]));
  updateExample();

  // ------------------------------------------------------------ выдача
  const LABELS = { zip: "Скачать ZIP", pdf: "Скачать PDF" };
  async function generate(format, card, button) {
    if (busy) return;
    if (proj.rows.length > LIMITS.maxRows) { toast(`Слишком много строк: максимум ${LIMITS.maxRows}`, "err"); return; }
    if (lastCheck && (lastCheck.problems.length || lastCheck.config_errors.length)) {
      const bad = new Set(lastCheck.problems.map((p) => p.row)).size;
      const what = [];
      if (lastCheck.config_errors.length) what.push(`в настройках бланков: ${lastCheck.config_errors.length} (поля не найдут свои колонки и останутся пустыми)`);
      if (bad) what.push(`в строках: ${bad} (текст будет обрезан или пропущен)`);
      const ok = await confirmDialog({ title: "Найдены проблемы", text: `Проверка нашла проблемы ${what.join("; ")}. Всё равно скачать?`, ok: "Всё равно скачать", danger: true });
      if (!ok) return;
    }
    const est = api.estimate(proj, format);
    if (est.files > 1) {
      const ok = await confirmDialog({ title: "Результат большой", text: `Около ${mb(est.bytes)} МБ — он скачается несколькими файлами (${est.files}). Браузер может спросить разрешение на несколько загрузок — разрешите.`, ok: "Продолжить" });
      if (!ok) return;
    }
    busy = true;
    layout.classList.add("busy");
    button.disabled = true;
    const bar = card.querySelector(".progress"), fill = bar.firstElementChild, label = card.querySelector(".progress-label");
    bar.hidden = false; label.hidden = false; fill.style.width = "0%"; label.textContent = "Готовлю…";
    try {
      const res = await api.generate(state.pid, format,
        (done, total) => { fill.style.width = Math.round((done / total) * 100) + "%"; label.textContent = `Генерирую… ${done} из ${total}`; },
        async (f) => { saveBlob(f.blob, f.filename); await new Promise((r) => setTimeout(r, 600)); });  // пауза: браузеры блокируют «залп» загрузок
      fill.style.width = "100%";
      let msg = (format === "zip" ? "ZIP готов" : "PDF готов") + (res.count > 1 ? ` (файлов: ${res.count})` : "");
      if (res.problems) msg += `. Строк с проблемами: ${res.problems}`;
      label.textContent = msg;
      toast(msg, res.problems ? "err" : "ok");
    } catch (e) { label.textContent = ""; label.hidden = true; bar.hidden = true; toast(e.message, "err"); }
    finally { busy = false; layout.classList.remove("busy"); button.disabled = !canExport; }
  }

  function formatCard(format, ico, title, text, primary) {
    const est = canExport ? api.estimate(proj, format) : null;
    const button = btn(LABELS[format], { cls: "btn lg " + (primary ? "brass" : "secondary"), ico: "download", disabled: !canExport });
    const card = el("article", { class: "format-card" + (primary ? " primary" : "") }, [
      el("div", { class: "fc-ico", html: icon(ico, "lg") }),
      el("h4", {}, title),
      el("p", { class: "hint" }, text),
      est ? el("p", { class: "fc-size" }, [`≈ ${mb(est.bytes)} МБ`, est.files > 1 ? ` · файлов: ${est.files}` : ""]) : null,
      button,
      el("div", { class: "progress", hidden: "" }, el("i")),
      el("p", { class: "progress-label hint", hidden: "" }),
    ]);
    button.addEventListener("click", () => generate(format, card, button));
    return card;
  }
  main.appendChild(el("div", { class: "format-grid" }, [
    formatCard("zip", "zip", "Архив PNG", "Отдельная картинка на каждую строку таблицы — удобно для рассылки или печати по одному.", true),
    formatCard("pdf", "printer", "Один PDF для печати", `Все документы подряд, страница — формат A4. Если страниц больше ${LIMITS.pdfPartPages} или файл очень большой, он делится на несколько PDF.`, false),
  ]));
  main.appendChild(el("p", { class: "privacy-note", html: icon("shield") + "<span>Проект хранится только в вашем браузере. При генерации бланки и таблица уходят на сервер на время запроса и не сохраняются.</span>" }));

  // ------------------------------------------------------------ готовность и проверка
  const checks = el("ul", { class: "checklist" });
  const validateBox = el("div", { class: "validate-box" });
  side.appendChild(el("section", { class: "panel" }, [el("h3", {}, "Готовность"), checks]));
  side.appendChild(el("section", { class: "panel" }, [el("h3", {}, "Проверка текста"), validateBox]));

  const check = (ok, text, fix) => el("li", { class: ok === true ? "ok" : ok === false ? "bad" : "wait" }, [
    el("span", { class: "ck", html: ok === true ? icon("check") : ok === false ? icon("x") : '<span class="spin"></span>' }),
    el("span", {}, text),
    fix && ok === false ? el("a", { href: fix[1] }, fix[0]) : null,
  ]);
  function drawChecks(valid) {
    checks.innerHTML = "";
    checks.appendChild(check(proj.templates.length > 0, proj.templates.length ? `Бланков: ${proj.templates.length}` : "Нет ни одного бланка", ["Добавить", `#/p/${state.pid}/templates`]));
    checks.appendChild(check(proj.rows.length > 0, proj.rows.length ? `Строк в таблице: ${proj.rows.length}` : "Таблица пуста", ["Заполнить", `#/p/${state.pid}/data`]));
    if (proj.templates.length > 1) checks.appendChild(check(!!proj.match_column, proj.match_column ? `Тип бланка по колонке «${proj.match_column}»` : "Не выбрана колонка типа", ["Выбрать", `#/p/${state.pid}/templates`]));
    if (canExport) checks.appendChild(check(valid, valid === true ? "Текст везде помещается" : valid === false ? "Есть проблемы с текстом" : "Проверяю все строки…"));
  }
  drawChecks(canExport ? null : undefined);

  async function runValidate() {
    if (!canExport) { validateBox.appendChild(el("p", { class: "hint" }, "Проверка станет доступна, когда будут бланк и данные.")); return; }
    validateBox.innerHTML = "";
    const status = el("p", { class: "hint" }, "Проверяю все строки…");
    validateBox.appendChild(status);
    try {
      const res = await api.validate(state.pid, (done, total) => { status.textContent = `Проверяю строки… ${done} из ${total}`; });
      validateBox.innerHTML = "";
      lastCheck = res;
      const clean = !res.problems.length && !res.config_errors.length;
      drawChecks(clean);
      validateBox.appendChild(el("p", { class: "hint" }, `Проверено строк: ${res.total_rows}`));
      if (clean) { validateBox.appendChild(el("div", { class: "note ok", html: icon("check") }, el("span", {}, "Всё в порядке, можно скачивать"))); return; }
      res.config_errors.forEach((m) => validateBox.appendChild(el("div", { class: "problem-row" }, [
        el("span", { class: "rn" }, "Бланк"), el("span", { class: "msg" }, m),
        el("a", { class: "btn ghost sm", href: `#/p/${state.pid}/templates` }, "Открыть"),
      ])));
      res.problems.slice(0, 200).forEach((p) => validateBox.appendChild(el("div", { class: "problem-row" }, [
        el("span", { class: "rn" }, `#${p.row + 1}`), el("span", { class: "msg" }, p.msg),
        el("a", { class: "btn ghost sm", href: `#/p/${state.pid}/data` }, "Таблица"),
      ])));
      if (res.problems.length > 200) validateBox.appendChild(el("p", { class: "hint" }, `…и ещё проблем: ${res.problems.length - 200}`));
    } catch (e) {
      validateBox.innerHTML = "";
      drawChecks(false);
      validateBox.appendChild(el("div", { class: "note err", html: icon("alert") }, el("span", {}, "Не удалось выполнить проверку: " + e.message)));
    }
  }
  runValidate();
}
