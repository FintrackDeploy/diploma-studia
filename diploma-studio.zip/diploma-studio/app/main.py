# -*- coding: utf-8 -*-
"""Stateless FastAPI: сервер ничего не хранит, каждый запрос самодостаточен.

Защита ресурсов (всё работает и без nginx, nginx — вторая линия):
  * Guard: лимит размера тела по Content-Length и частота запросов с одного адреса;
  * slot(): не более MAX_JOBS одновременных задач и очередь не длиннее MAX_QUEUE (иначе 503);
  * шаблоны читаются и декодируются только внутри слота и только используемые строками;
  * в памяти одновременно живёт одно декодированное изображение шаблона.
"""
import asyncio
import io
import json
import logging
import os
import time
import zipfile
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import quote

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from openpyxl import load_workbook
from PIL import Image
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from starlette.concurrency import run_in_threadpool

from . import engine
from .sanitize import MAX_ROWS, ProjectError, sanitize_project

log = logging.getLogger("diploma")
if not logging.getLogger().handlers:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

BASE = Path(__file__).resolve().parent
GALLERY = BASE / "gallery"
STATIC = BASE / "static"

MB = 1024 * 1024
MAX_BATCH_ROWS = 500                  # строк за один запрос генерации
MAX_PROJECT_JSON = 25 * MB            # описание проекта (без картинок)
MAX_TEMPLATE_FILE = 20 * MB
MAX_TEMPLATES_TOTAL = 100 * MB
MAX_TEMPLATE_PIXELS = 25_000_000      # 5000×5000; клиент сам уменьшает до 4000 px по длинной стороне
MAX_TEMPLATE_SIDE = 4000
MAX_EXCEL = 50 * MB
MAX_XLSX_UNPACKED = 150 * MB          # суммарный размер xlsx после распаковки (защита от zip-бомб)
MAX_XLSX_SCAN_ROWS = 200_000          # просмотренных строк листа, включая пустые
MAX_VALIDATE_BODY = 30 * MB
A4_LONG_PT = 297 / 25.4 * 72          # длинная сторона страницы PDF

MAX_JOBS = int(os.getenv("MAX_JOBS", "2"))
MAX_QUEUE = int(os.getenv("MAX_QUEUE", "16"))          # сколько запросов может ждать свободного слота
RATE_LIMIT = int(os.getenv("RATE_LIMIT", "300"))       # запросов к /api/ в минуту с одного адреса; 0 — выкл.

JOBS = asyncio.Semaphore(MAX_JOBS)
_inflight = 0

# Изображения открываем только как PNG/JPEG; размеры проверяем по заголовку до декодирования.
Image.MAX_IMAGE_PIXELS = None
ALLOWED_FORMATS = ("PNG", "JPEG")

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' blob: data:; font-src 'self'; connect-src 'self'; worker-src 'self' blob:; "
       "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")


# --------------------------------------------------------------------------- защита

_HITS: dict[str, deque] = {}


def _allow(ip: str) -> bool:
    now = time.monotonic()
    q = _HITS.setdefault(ip, deque())
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        return False
    q.append(now)
    if len(_HITS) > 20000:                       # не даём словарю расти бесконечно
        for k in [k for k, v in _HITS.items() if not v or now - v[-1] > 60]:
            _HITS.pop(k, None)
    return True


def body_limit(path: str) -> int:
    if path == "/api/validate":
        return MAX_VALIDATE_BODY
    if path == "/api/parse-excel":
        return MAX_EXCEL + MB
    return MAX_TEMPLATES_TOTAL + MAX_PROJECT_JSON + MB


async def _reject(scope, receive, send, code: int, msg: str, headers: dict | None = None):
    await JSONResponse({"detail": msg}, status_code=code, headers=headers)(scope, receive, send)


class Guard:
    """ASGI-защита /api/: размер тела (по Content-Length) и частота запросов."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope["path"].startswith("/api/"):
            return await self.app(scope, receive, send)
        ip = (scope.get("client") or ("?", 0))[0]
        if RATE_LIMIT and not _allow(ip):
            return await _reject(scope, receive, send, 429, "Слишком много запросов. Подождите немного.",
                                 {"Retry-After": "10"})
        if scope["method"] in ("POST", "PUT", "PATCH"):
            cl = dict(scope["headers"]).get(b"content-length")
            if cl is None:
                return await _reject(scope, receive, send, 411, "Нужен заголовок Content-Length")
            try:
                n = int(cl)
            except ValueError:
                return await _reject(scope, receive, send, 400, "Некорректный Content-Length")
            if n > body_limit(scope["path"]):
                return await _reject(scope, receive, send, 413, "Запрос слишком большой")
        await self.app(scope, receive, send)


@asynccontextmanager
async def slot():
    """Слот тяжёлой задачи. Если очередь переполнена — 503, а не рост памяти."""
    global _inflight
    if _inflight >= MAX_JOBS + MAX_QUEUE:
        raise HTTPException(503, "Сервер сейчас занят. Повторите через минуту.", headers={"Retry-After": "30"})
    _inflight += 1
    try:
        async with JOBS:
            yield
    finally:
        _inflight -= 1


app = FastAPI(title="Diploma Studio", docs_url=None, redoc_url=None)
app.add_middleware(Guard)


@app.middleware("http")
async def headers_mw(request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path.startswith("/gallery-files/"):
        response.headers["Cache-Control"] = "no-cache"
    elif path.startswith("/vendor/"):
        response.headers["Cache-Control"] = "public, max-age=604800"
    elif path.startswith("/api/") or path == "/healthz":
        response.headers["Cache-Control"] = "no-store"
    else:
        # Интерфейс обновляется вместе с приложением: браузер каждый раз сверяет ETag (304 без тела).
        response.headers["Cache-Control"] = "no-cache"
    h = response.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("Referrer-Policy", "no-referrer")
    h.setdefault("Content-Security-Policy", CSP)
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
    if response.status_code >= 500:
        log.warning("%s %s -> %s", request.method, path, response.status_code)
    return response


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    # В лог попадает только тип ошибки и стек, но не содержимое запроса (ФИО и т. п.).
    log.error("необработанная ошибка %s %s: %s", request.method, request.url.path, type(exc).__name__, exc_info=exc)
    return JSONResponse({"detail": "Внутренняя ошибка сервера"}, status_code=500)


app.mount("/gallery-files", StaticFiles(directory=GALLERY), name="gallery-files")


# --------------------------------------------------------------------------- вспомогательное

async def read_limited(f: UploadFile, limit: int, msg: str) -> bytes:
    data = await f.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, msg)
    return data


def parse_project(raw: bytes, max_rows: int = MAX_ROWS) -> dict:
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(400, "Некорректное описание проекта")
    try:
        return sanitize_project(data, max_rows)
    except ProjectError as e:
        raise HTTPException(400, str(e))


_ORIENT = {2: Image.Transpose.FLIP_LEFT_RIGHT, 3: Image.Transpose.ROTATE_180, 4: Image.Transpose.FLIP_TOP_BOTTOM,
           5: Image.Transpose.TRANSPOSE, 6: Image.Transpose.ROTATE_270, 7: Image.Transpose.TRANSVERSE,
           8: Image.Transpose.ROTATE_90}


def load_template_image(raw: bytes, tpl: dict) -> Image.Image:
    """Декодирует шаблон. Размер проверяется по заголовку до загрузки пикселей."""
    name = tpl.get("name", "")
    try:
        im = Image.open(io.BytesIO(raw), formats=ALLOWED_FORMATS)
        if im.width * im.height > MAX_TEMPLATE_PIXELS:
            raise HTTPException(400, f"Шаблон «{name}» слишком большой по размеру изображения")
        try:
            orient = int(im.getexif().get(0x0112, 1))
        except Exception:
            orient = 1
        if im.format == "JPEG" and max(im.size) > MAX_TEMPLATE_SIDE:
            im.draft("RGB", (MAX_TEMPLATE_SIDE, MAX_TEMPLATE_SIDE))   # декодирование сразу в 1/2…1/8 размера
        im.load()
        im = engine.flatten_rgb(im)
        if orient in _ORIENT:
            im = im.transpose(_ORIENT[orient])
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(400, f"Не удалось прочитать шаблон «{name}»")
    if max(im.size) > MAX_TEMPLATE_SIDE:
        im.thumbnail((MAX_TEMPLATE_SIDE, MAX_TEMPLATE_SIDE), Image.LANCZOS)
    # зоны заданы в пикселях изображения, каким его видел браузер; при расхождении масштабируем
    if tpl.get("w") and tpl.get("h") and (im.width != tpl["w"] or im.height != tpl["h"]):
        kx, ky = im.width / tpl["w"], im.height / tpl["h"]
        for g in tpl["groups"]:
            x1, y1, x2, y2 = g["zone"]
            g["zone"] = [x1 * kx, y1 * ky, x2 * kx, y2 * ky]
    tpl["w"], tpl["h"] = im.size
    return im


def row_template(project: dict, row: dict, n: int | None = None):
    tpl, err = engine.pick_template(project["templates"], project["match_column"], row)
    if err:
        raise HTTPException(400, (f"Строка {n}: " if n else "") + err)
    return tpl


def pick_all(project: dict, start: int) -> list[dict]:
    return [row_template(project, row, start + i) for i, row in enumerate(project["rows"])]


async def read_templates(files: list[UploadFile], needed: set[str], names: dict[str, str]) -> dict[str, bytes]:
    """Читает только файлы нужных шаблонов. Вызывается внутри slot()."""
    if len(files or []) > 40:
        raise HTTPException(400, "Слишком много файлов шаблонов")
    raw_map, total = {}, 0
    for f in files or []:
        stem = Path(f.filename or "").stem
        if stem not in needed or stem in raw_map:
            continue
        raw = await read_limited(f, MAX_TEMPLATE_FILE, "Один шаблон больше 20 МБ")
        total += len(raw)
        if total > MAX_TEMPLATES_TOTAL:
            raise HTTPException(413, "Суммарный размер шаблонов больше 100 МБ")
        raw_map[stem] = raw
    for tid in needed:
        if tid not in raw_map:
            raise HTTPException(400, f"Не найден файл шаблона «{names.get(tid, tid)}»")
    return raw_map


def png_dpi(im: Image.Image) -> int:
    return max(72, round(max(im.size) / (297 / 25.4)))


def render_grouped(project: dict, picks: list[dict], raw_map: dict[str, bytes], start: int, encode):
    """Рисует строки, группируя по шаблону: в памяти одновременно только одна картинка шаблона.

    Возвращает список (данные, есть_ошибка, размер) в исходном порядке строк.
    """
    rows = project["rows"]
    by_tpl: dict[str, list[int]] = {}
    for i, t in enumerate(picks):
        by_tpl.setdefault(t["id"], []).append(i)
    out = [None] * len(rows)
    for tid, idxs in by_tpl.items():
        tpl = picks[idxs[0]]
        base = load_template_image(raw_map[tid], tpl)
        for i in idxs:
            im, warnings = engine.render(base, tpl, rows[i])
            out[i] = (encode(im), engine.has_errors(warnings), im.size)
        del base
    return out


# --------------------------------------------------------------------------- API

@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/api/gallery")
def api_gallery():
    items = json.loads((GALLERY / "gallery.json").read_text(encoding="utf-8"))
    for it in items:
        # «ревизия» картинок набора: меняется вместе с файлами, поэтому браузер не показывает устаревшие превью
        files = [GALLERY / t for t in it.get("thumbs", [])] + [GALLERY / t["image"] for t in it.get("templates", [])]
        it["rev"] = max((f.stat().st_mtime_ns for f in files if f.exists()), default=0) // 1_000_000_000
    return items


@app.get("/api/limits")
def api_limits():
    return {"max_rows": MAX_ROWS, "batch_rows": MAX_BATCH_ROWS}


def _check_xlsx_archive(raw: bytes):
    """xlsx — это zip. Проверяем реальный распакованный размер, а не заявленный в заголовках."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
        infos = zf.infolist()
    except zipfile.BadZipFile:
        raise HTTPException(400, "Не удалось прочитать Excel-файл (.xlsx)")
    if len(infos) > 500:
        raise HTTPException(400, "Excel-файл повреждён или слишком сложный")
    total = 0
    for info in infos:
        with zf.open(info) as f:
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_XLSX_UNPACKED:
                    raise HTTPException(400, "Excel-файл слишком большой после распаковки")


def _parse_excel(raw: bytes) -> dict:
    _check_xlsx_archive(raw)
    try:
        wb = load_workbook(io.BytesIO(raw), data_only=True, read_only=True)
    except Exception:
        raise HTTPException(400, "Не удалось прочитать Excel-файл (.xlsx)")
    try:
        ws = wb.active
        first = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
        headers, seen = [], {}
        for v in first:
            h = engine.clean(v) if v is not None else ""
            if h:  # повторяющиеся заголовки не должны затирать друг друга
                seen[h] = seen.get(h, 0) + 1
                if seen[h] > 1:
                    h = f"{h} ({seen[h]})"
            headers.append(h)
        while headers and not headers[-1]:
            headers.pop()
        if not headers:
            raise HTTPException(400, "В первой строке файла нет заголовков колонок")
        if len(headers) > 300:
            raise HTTPException(400, "В файле больше 300 колонок")
        rows, scanned = [], 0
        for values in ws.iter_rows(min_row=2, values_only=True):
            scanned += 1
            if scanned > MAX_XLSX_SCAN_ROWS:
                raise HTTPException(400, "В листе слишком много строк (включая пустые)")
            row = {h: engine.clean(values[i]) for i, h in enumerate(headers) if h and i < len(values)}
            if any(row.values()):
                rows.append(row)
                if len(rows) > MAX_ROWS:
                    raise HTTPException(400, f"В Excel больше {MAX_ROWS} заполненных строк")
        if not rows:
            raise HTTPException(400, "В файле нет заполненных строк данных")
        return {"columns": [h for h in headers if h], "rows": rows}
    finally:
        wb.close()


@app.post("/api/parse-excel")
async def parse_excel(file: UploadFile = File(...)):
    async with slot():
        raw = await read_limited(file, MAX_EXCEL, "Excel-файл больше 50 МБ")
        return await run_in_threadpool(_parse_excel, raw)


def config_errors(project: dict) -> list[str]:
    """Привязки, которые ссылаются на несуществующие колонки: иначе поля молча остаются пустыми."""
    cols = set(project["columns"]) or {k for r in project["rows"] for k in r}
    if not cols:
        return []
    errors = []
    mc = project["match_column"]
    if len(project["templates"]) > 1 and mc and mc not in cols:
        errors.append(f"Колонка «{mc}», по которой выбирается шаблон, не найдена в таблице")
    used = set()
    for row in project["rows"]:
        tpl, err = engine.pick_template(project["templates"], mc, row)
        if tpl:
            used.add(tpl["id"])
    for tpl in project["templates"]:
        if tpl["id"] not in used:
            continue
        for g in tpl["groups"]:
            for f in g["fields"]:
                if f["source"]["type"] != "column":
                    continue
                for c in f["source"]["columns"]:
                    if c and c not in cols:
                        errors.append(f"Шаблон «{tpl['name']}», поле «{f['name']}»: в таблице нет колонки «{c}»")
    return list(dict.fromkeys(errors))[:50]


def _validate(project: dict) -> dict:
    problems = []
    dims_ok = {t["id"]: bool(t["w"] and t["h"]) for t in project["templates"]}
    for i, row in enumerate(project["rows"]):
        tpl, err = engine.pick_template(project["templates"], project["match_column"], row)
        if err:
            problems.append({"row": i, "level": "error", "msg": err})
            continue
        if not dims_ok[tpl["id"]]:
            problems.append({"row": i, "level": "error", "msg": f"у шаблона «{tpl['name']}» неизвестен размер"})
            continue
        _, warnings = engine.plan(tpl["w"], tpl["h"], tpl, row)
        for w in warnings:
            if w["level"] == "error":
                problems.append({"row": i, "level": "error", "msg": w["msg"]})
    return {"total_rows": len(project["rows"]), "problems": problems, "config_errors": config_errors(project)}


@app.post("/api/validate")
async def validate(request: Request):
    """Проверка данных без картинок. Размер тела ограничен в Guard (по Content-Length)."""
    raw = await request.body()
    project = parse_project(raw)
    async with slot():
        return await run_in_threadpool(_validate, project)


def _render_preview(project: dict, tpl: dict, raw: bytes) -> Response:
    base = load_template_image(raw, tpl)
    im, warnings = engine.render(base, tpl, project["rows"][0])
    if im.width > 700:
        im = im.resize((700, round(im.height * 700 / im.width)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=90)
    return Response(content=buf.getvalue(), media_type="image/jpeg", headers={
        "X-Warnings": quote(json.dumps(warnings, ensure_ascii=False)),
        "X-Template": quote(tpl["name"]),
    })


@app.post("/api/render/preview")
async def render_preview(project: UploadFile = File(...), template_files: list[UploadFile] = File(default=[])):
    async with slot():
        proj = parse_project(await read_limited(project, MAX_PROJECT_JSON, "Описание проекта слишком большое"))
        if len(proj["rows"]) != 1:
            raise HTTPException(400, "Для предпросмотра нужен ровно один ряд данных")
        tpl = row_template(proj, proj["rows"][0])
        raw_map = await read_templates(template_files, {tpl["id"]}, {tpl["id"]: tpl["name"]})
        return await run_in_threadpool(_render_preview, proj, tpl, raw_map[tpl["id"]])


def _build_zip(project: dict, picks: list, raw_map: dict, start: int) -> Response:
    def encode(im):
        out, d = io.BytesIO(), png_dpi(im)
        im.save(out, "PNG", dpi=(d, d))
        return out.getvalue()

    results = render_grouped(project, picks, raw_map, start, encode)
    buf, problem_rows = io.BytesIO(), 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as zf:  # PNG уже сжат, повторно жать нет смысла
        for i, (data, bad, _size) in enumerate(results):
            n = start + i
            name = engine.make_filename(project["filename_pattern"], project["rows"][i], n)
            # Префикс с номером строки делает имена уникальными внутри пачки; клиент его снимает
            # и сам расставляет суффиксы _2, _3 для повторов во всём архиве.
            zf.writestr(f"{n:05d}__{name}.png", data)
            problem_rows += bad
            results[i] = None
    return Response(buf.getvalue(), media_type="application/zip", headers={"X-Problem-Rows": str(problem_rows)})


def _build_pdf(project: dict, picks: list, raw_map: dict, start: int) -> Response:
    def encode(im):
        jpg = io.BytesIO()
        im.save(jpg, "JPEG", quality=95, subsampling=0)
        return jpg.getvalue()

    results = render_grouped(project, picks, raw_map, start, encode)
    buf, pdf, problem_rows = io.BytesIO(), None, 0
    for i, (data, bad, size) in enumerate(results):
        problem_rows += bad
        # Страница всегда A4-размера (длинная сторона 297 мм), независимо от пикселей шаблона.
        k = A4_LONG_PT / max(size)
        page_w, page_h = size[0] * k, size[1] * k
        if pdf is None:
            pdf = canvas.Canvas(buf, pagesize=(page_w, page_h), pageCompression=1)
        else:
            pdf.setPageSize((page_w, page_h))
        pdf.drawImage(ImageReader(io.BytesIO(data)), 0, 0, width=page_w, height=page_h)
        pdf.showPage()
        results[i] = None
    if pdf is None:
        raise HTTPException(400, "Нечего собирать в PDF")
    pdf.save()
    return Response(buf.getvalue(), media_type="application/pdf", headers={"X-Problem-Rows": str(problem_rows)})


async def _generate(builder, project: UploadFile, template_files: list[UploadFile], start: int):
    async with slot():
        proj = parse_project(await read_limited(project, MAX_PROJECT_JSON, "Описание проекта слишком большое"),
                             MAX_BATCH_ROWS)
        if not proj["rows"]:
            raise HTTPException(400, "Нет данных для генерации")
        start = max(1, start)
        picks = pick_all(proj, start)
        needed = {t["id"] for t in picks}
        raw_map = await read_templates(template_files, needed, {t["id"]: t["name"] for t in picks})
        return await run_in_threadpool(builder, proj, picks, raw_map, start)


@app.post("/api/generate/zip")
async def generate_zip(project: UploadFile = File(...), template_files: list[UploadFile] = File(default=[]),
                       start: int = Form(1)):
    """ZIP с PNG для пачки строк (не более 500). `start` — номер первой строки для {n}."""
    return await _generate(_build_zip, project, template_files, start)


@app.post("/api/generate/pdf")
async def generate_pdf(project: UploadFile = File(...), template_files: list[UploadFile] = File(default=[]),
                       start: int = Form(1)):
    """PDF (A4, по странице на строку) для пачки строк (не более 500)."""
    return await _generate(_build_pdf, project, template_files, start)


app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
