# -*- coding: utf-8 -*-
"""
Движок раскладки дипломов.

Обобщение исходного скрипта: вместо зашитых в код зон и размеров шрифта всё описывается
JSON-конфигом шаблона:

template = {
  "id", "name", "image", "w", "h", "match": ["грамота", ...],
  "groups": [{
      "id", "name",
      "zone": [x1, y1, x2, y2],      # в пикселях изображения шаблона
      "valign": 0.5,                 # 0 — прижать к верху зоны, 0.5 — по центру
      "halo": 0,                     # 0..255: приглушение фона (водяного знака) под текстом
      "fields": [{
          "id", "name",
          "source": {"type": "column", "columns": ["ФИО"], "join": "\n"}   # или {"type":"text","value":"..."}
          "part": "all" | "surname" | "given",
          "transform": "none" | "upper" | "lower" | "title",
          "font": {"family": "Liberation Serif", "bold": true, "color": "#000000"},
          "size_max", "size_min",    # пределы авторазмера шрифта, px
          "line_gap",                # межстрочный интервал, px
          "gap_after",               # отступ до следующего блока, px
          "align": "center" | "left" | "right",
          "stretch_x": false,        # (только вместе с fill) ещё и растянуть по ширине до краёв зоны
          "fill": false,             # растянуть текст на всю свободную область зоны (макс. размер игнорируется)
          "max_height_pct": null,    # ограничить высоту блока долей зоны (в %)
          "required": false
      }]
  }]
}

Предпросмотр и итоговый файл рисуются одним и тем же кодом в полном разрешении;
предпросмотр — это просто уменьшенная копия готового результата (WYSIWYG).
"""
from __future__ import annotations

import datetime as _dt
import math
import difflib
import re
import unicodedata
import threading
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

FONTS_DIR = Path(__file__).resolve().parent / "fonts"
FONT_FAMILIES = {
    "Liberation Serif": ("LiberationSerif-Regular.ttf", "LiberationSerif-Bold.ttf"),
    "Liberation Sans": ("LiberationSans-Regular.ttf", "LiberationSans-Bold.ttf"),
    "DejaVu Serif": ("DejaVuSerif.ttf", "DejaVuSerif-Bold.ttf"),
}
DEFAULT_FAMILY = "Liberation Serif"

# Ширина «эталонного» шаблона из исходного скрипта — нужна для масштаба подложки.
REF_W = 1054


# --------------------------------------------------------------------------- утилиты

def clean(v) -> str:
    if v is None:
        return ""
    if isinstance(v, _dt.datetime):
        return v.strftime("%d.%m.%Y" if not (v.hour or v.minute or v.second) else "%d.%m.%Y %H:%M")
    if isinstance(v, _dt.date):
        return v.strftime("%d.%m.%Y")
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def norm_key(s) -> str:
    s = clean(s).lower().replace("ё", "е")
    s = re.sub(r"\s+", " ", s)
    return s.strip(" .,:;")


_PATRONYMIC = re.compile(r".*(ович|евич|ич|овна|евна|ична|инична|ьич|іч|аўна|оўна|еўна|ўна|ічна)$")


def _is_patronymic(word: str) -> bool:
    return bool(_PATRONYMIC.fullmatch(word.lower().replace("ё", "е")))


def split_fio(fio: str):
    """Возвращает (фамилия, имя и отчество).

    Понимает «Фамилия Имя Отчество» и «Имя Отчество Фамилия». Порядок определяется по
    положению отчества: если оно стоит вторым, а первое слово на отчество не похоже —
    это «Имя Отчество Фамилия» (даже если сама фамилия оканчивается на -ович/-евич,
    как «Адамович» или «Ковалевич»). Во всех остальных случаях — «Фамилия Имя Отчество».
    """
    fio = re.sub(r"[,\s]+$", "", clean(fio))
    parts = re.split(r"\s+", fio) if fio else []
    if len(parts) >= 3:
        if _is_patronymic(parts[1]) and not _is_patronymic(parts[0]):
            return " ".join(parts[2:]), " ".join(parts[:2])
        return parts[0], " ".join(parts[1:])
    if len(parts) == 2:
        return parts[0], parts[1]
    return fio, ""


def hex_to_rgb(value: str):
    value = (value or "#000000").lstrip("#")
    if len(value) == 3:
        value = "".join(c * 2 for c in value)
    try:
        return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return (0, 0, 0)


_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def safe_filename(name: str) -> str:
    name = unicodedata.normalize("NFC", clean(name))     # macOS отдаёт NFD, Windows ждёт NFC
    name = re.sub(r'[\\/:*?"<>|\r\n\t\x00-\x1f]+', "_", name)
    name = re.sub(r"\s+", " ", name).strip(" .")
    name = (name or "diploma")[:120].rstrip(" .")
    if name.split(".")[0].upper() in _RESERVED:           # CON, NUL, COM1… нельзя создать в Windows
        name = "_" + name
    return name


def make_filename(pattern: str, row: dict, n: int) -> str:
    pattern = pattern or "{n}"

    def repl(m):
        key = m.group(1)
        if key in ("n", "№"):
            return f"{n:03d}"
        return clean(row.get(key, ""))

    pattern = pattern.replace("№", "{n}")
    return safe_filename(re.sub(r"\{([^{}]+)\}", repl, pattern))


# --------------------------------------------------------------------------- шрифты и текст

_TLS = threading.local()


def load_font(family: str, bold: bool, size: int) -> ImageFont.FreeTypeFont:
    """Шрифты FreeType не потокобезопасны, поэтому кэш свой у каждого потока."""
    cache = getattr(_TLS, "fonts", None)
    if cache is None:
        cache = _TLS.fonts = {}
    size = max(6, min(2000, int(size)))
    key = (family, bool(bold), size)
    f = cache.get(key)
    if f is None:
        if len(cache) > 600:
            cache.clear()
        regular, bold_file = FONT_FAMILIES.get(family, FONT_FAMILIES[DEFAULT_FAMILY])
        f = cache[key] = ImageFont.truetype(str(FONTS_DIR / (bold_file if bold else regular)), size)
    return f


def _measure():
    d = getattr(_TLS, "measure", None)
    if d is None:
        d = _TLS.measure = ImageDraw.Draw(Image.new("L", (8, 8)))
    return d


_ABBREV = {
    "г.", "д.", "ул.", "пр.", "пр-т", "просп.", "пер.",
    "пл.", "наб.", "ш.", "к.", "корп.", "стр.", "им.", "№",
}


def _text_width(text, f):
    b = _measure().textbbox((0, 0), text, font=f)
    return b[2] - b[0]


def _tokenize(text):
    """Слова с «приклеенными» сокращениями (г. Гродно, И.О., им. Иванова)."""
    text = re.sub(r"[ \t]+", " ", text.strip())
    if not text:
        return []
    words = text.split(" ")
    tokens, i = [], 0
    while i < len(words):
        word = words[i]
        if word.lower() in _ABBREV and i + 1 < len(words):
            group = word + "\u00a0" + words[i + 1]
            i += 2
            if word.lower() == "им.":
                extra = 0
                while i < len(words) and extra < 2:
                    group += "\u00a0" + words[i]
                    i += 1
                    extra += 1
            tokens.append(group)
            continue
        if re.fullmatch(r"(?:[А-ЯЁ]\.){1,3}", word) and i + 1 < len(words):
            tokens.append(word + "\u00a0" + words[i + 1])
            i += 2
            continue
        tokens.append(word)
        i += 1
    return tokens


@lru_cache(maxsize=4096)
def wrapped(text: str, family: str, bold: bool, size: int, width: int) -> str:
    f = load_font(family, bold, size)
    out = []
    for paragraph in text.split("\n"):
        tokens = _tokenize(paragraph)
        if not tokens:
            out.append("")
            continue
        lines, line = [], ""
        for token in tokens:
            cand = token if not line else line + " " + token
            if _text_width(cand, f) <= width:
                line = cand
                continue
            if line:
                lines.append(line)
                line = ""
            if _text_width(token, f) <= width:
                line = token
            else:  # слишком длинное слово — режем по символам
                chunk = ""
                for ch in token:
                    if _text_width(chunk + ch, f) <= width:
                        chunk += ch
                    else:
                        if chunk:
                            lines.append(chunk)
                        chunk = ch
                line = chunk
        if line:
            lines.append(line)
        out.extend(lines)
    return "\n".join(out)


@lru_cache(maxsize=4096)
def block_bbox(value: str, family: str, bold: bool, size: int, spacing: int):
    f = load_font(family, bold, size)
    return _measure().multiline_textbbox((0, 0), value, font=f, spacing=spacing, align="center")


def _has_broken_word(text, family, bold, size, width):
    """True, если хоть одно слово шире зоны (его пришлось бы резать посередине)."""
    f = load_font(family, bold, size)
    for paragraph in text.split("\n"):
        for token in _tokenize(paragraph):
            if _text_width(token, f) > width:
                return True
    return False


def _fit(text, size_max, size_min, family, bold, width, max_h, spacing, strict=False):
    """Наибольший размер шрифта, при котором текст помещается по высоте (бинарный поиск).

    strict=True — режим «на всю область»: дополнительно слова не должны резаться посередине,
    так что размер ограничивает либо высота, либо ширина самого длинного слова.
    """
    hi = max(int(round(size_max)), int(round(size_min)))
    lo = int(round(size_min))

    def measure(size):
        v = wrapped(text, family, bold, size, width)
        b = block_bbox(v, family, bold, size, spacing)
        return v, b

    def fits(size, v, b):
        if b[3] - b[1] > max_h:
            return False
        return not (strict and _has_broken_word(text, family, bold, size, width))

    v, b = measure(lo)
    if b[3] - b[1] > max_h:
        return {"size": lo, "value": v, "h": b[3] - b[1], "bbox": b, "ok": False}
    best = (lo, v, b)  # минимальный размер принимаем всегда, если влезает по высоте
    left, right = lo, hi
    while left < right:
        mid = (left + right + 1) // 2
        v, b = measure(mid)
        if fits(mid, v, b):
            left, best = mid, (mid, v, b)
        else:
            right = mid - 1
    size, v, b = best
    return {"size": size, "value": v, "h": b[3] - b[1], "bbox": b, "ok": True}


# --------------------------------------------------------------------------- данные строки

def field_text(field: dict, row: dict) -> str:
    src = field.get("source") or {}
    if src.get("type") == "text":
        text = clean(src.get("value"))
    else:
        vals = [clean(row.get(c)) for c in src.get("columns", [])]
        text = (src.get("join", "\n") or "\n").join(v for v in vals if v)
    part = field.get("part", "all")
    if part in ("surname", "given"):
        surname, given = split_fio(text)
        text = surname if part == "surname" else given
    tr = field.get("transform", "none")
    if tr == "upper":
        text = text.upper()
    elif tr == "lower":
        text = text.lower()
    elif tr == "title":
        text = "|".join(" ".join(w[:1].upper() + w[1:].lower() for w in seg.split(" ")) for seg in text.split("|"))
    # «|» — принудительный перенос строки (в ячейке таблицы Enter не поставить)
    text = re.sub(r"[ \t]*\|[ \t]*", "\n", text)
    return text.strip()


def pick_template(templates: list, match_column: str | None, row: dict):
    """Возвращает (template | None, сообщение об ошибке).

    Сопоставление только точное (без учёта регистра, ё/е и лишних пробелов). «Умного»
    подбора по похожести нет намеренно: «III степени» нельзя молча принимать за «II степени».
    """
    if not templates:
        return None, "в проекте нет ни одного шаблона"
    if len(templates) == 1:
        return templates[0], ""
    if not match_column:
        return None, "не выбрана колонка, по которой определяется тип диплома (шаг «Шаблоны и поля»)"
    raw = clean(row.get(match_column))
    key = norm_key(raw)
    if not key:
        return None, f"не заполнено «{match_column}»"
    index = {}
    for t in templates:
        for m in list(t.get("match") or []) + [t.get("name", "")]:
            if norm_key(m):
                index[norm_key(m)] = t
    if key in index:
        return index[key], ""
    msg = f"неизвестное значение «{raw}» в колонке «{match_column}»"
    close = difflib.get_close_matches(key, list(index), n=1, cutoff=0.75)
    if close:
        msg += f" (возможно, «{index[close[0]].get('name', '')}»?)"
    return None, msg


def check_row(template: dict, row: dict) -> list:
    """Быстрая проверка без отрисовки: обязательные поля."""
    issues = []
    for g in template.get("groups", []):
        for f in g.get("fields", []):
            if f.get("required") and not field_text(f, row):
                issues.append(f"не заполнено поле «{f.get('name') or 'без названия'}»")
    return issues


# --------------------------------------------------------------------------- раскладка группы

def _layout_group(blocks, zone_w, zone_h):
    n = len(blocks)
    gaps = sum(b["gap"] for b in blocks[:-1])
    k = 1.0
    while True:
        res = [None] * n
        used = 0
        for i, b in enumerate(blocks):
            if b["fill"]:
                continue
            mx = max(b["min"], b["max"] * k)
            max_h = zone_h * b["hpct"] / 100 if b["hpct"] else zone_h
            res[i] = _fit(b["text"], mx, b["min"], b["family"], b["bold"], zone_w, max_h, b["spacing"])
            used += res[i]["h"]
        fills = [i for i, b in enumerate(blocks) if b["fill"]]
        remaining = zone_h - used - gaps
        for i in fills:
            b = blocks[i]
            share = max(1, remaining / len(fills))
            # «на всю область»: размер не ограничен «макс.» — растёт, пока текст помещается в зону
            res[i] = _fit(b["text"], max(b["max"], share, zone_w), b["min"], b["family"], b["bold"],
                          zone_w, share, b["spacing"], strict=True)
        total = sum(r["h"] for r in res) + gaps
        if total <= zone_h or k <= 0.3:
            return res, total
        k -= 0.02


def plan(W: int, H: int, template: dict, row: dict):
    """Раскладка без рисования: возвращает (список групп с позициями блоков, warnings).

    Не трогает пиксели, поэтому годится для быстрой проверки всех строк перед экспортом.
    """
    warnings = []
    groups = []
    for group in template.get("groups", []):
        x1, y1, x2, y2 = (int(round(v)) for v in group.get("zone", [0, 0, W, H]))
        x1, x2 = sorted((max(0, x1), min(W, x2)))
        y1, y2 = sorted((max(0, y1), min(H, y2)))
        zone_w, zone_h = max(20, x2 - x1), max(20, y2 - y1)

        blocks = []
        for f in group.get("fields", []):
            text = field_text(f, row)
            fname = f.get("name") or "без названия"
            if not text:
                if f.get("required"):
                    warnings.append({"level": "error", "field": fname,
                                     "msg": f"не заполнено поле «{fname}»"})
                continue
            font = f.get("font") or {}
            size_max = float(f.get("size_max") or 40)
            size_min = float(f.get("size_min") or 12)
            blocks.append({
                "field": f, "name": fname, "text": text,
                "family": font.get("family", DEFAULT_FAMILY), "bold": bool(font.get("bold", True)),
                "color": hex_to_rgb(font.get("color", "#000000")),
                "max": max(size_max, size_min), "min": size_min,
                "spacing": int(f.get("line_gap") if f.get("line_gap") is not None else 4),
                "gap": float(f.get("gap_after") or 0),
                "align": f.get("align", "center"),
                "fill": bool(f.get("fill")),
                "stretch": bool(f.get("fill") and f.get("stretch_x")),
                "hpct": f.get("max_height_pct") or 0,
            })
        if not blocks:
            continue

        res, total = _layout_group(blocks, zone_w, zone_h)
        overflow = total > zone_h + 0.5
        for b, r in zip(blocks, res):
            if overflow or not r["ok"]:
                warnings.append({"level": "error", "field": b["name"],
                                 "msg": f"«{b['name']}»: текст не помещается в зону даже минимальным шрифтом"})
                overflow = True
            elif r["size"] <= b["min"]:
                warnings.append({"level": "warn", "field": b["name"],
                                 "msg": f"«{b['name']}»: использован минимальный размер шрифта ({b['min']:g} px)"})

        y = y1 + max(0.0, (zone_h - total) * float(group.get("valign", 0.5)))
        placed = []
        for b, r in zip(blocks, res):
            bb = r["bbox"]
            w = bb[2] - bb[0]
            r["sx"] = 1.0
            if b["stretch"] and w > 0:
                r["sx"] = zone_w / w  # растянуть по горизонтали: самая длинная строка — до краёв зоны
                w = zone_w
            if b["align"] == "left":
                x = x1 - bb[0]
            elif b["align"] == "right":
                x = x2 - w - bb[0]
            else:
                x = x1 + (zone_w - w) / 2 - bb[0]
            placed.append((b, r, x, y, w))
            y += r["h"] + b["gap"]
        groups.append({"placed": placed, "halo": int(group.get("halo") or 0)})
    return groups, warnings


def flatten_rgb(im: Image.Image) -> Image.Image:
    """В RGB; прозрачность кладётся на белый фон (как в браузере), а не на чёрный."""
    if im.mode == "RGB":
        return im
    if im.mode in ("RGBA", "LA", "PA") or "transparency" in im.info:
        rgba = im.convert("RGBA")
        bg = Image.new("RGB", rgba.size, (255, 255, 255))
        bg.paste(rgba, mask=rgba.getchannel("A"))
        return bg
    return im.convert("RGB")


def render(base: Image.Image, template: dict, row: dict):
    """Рисует один диплом. Возвращает (Image, warnings)."""
    im = base.copy() if base.mode == "RGB" else flatten_rgb(base)
    W, H = im.size
    scale = W / REF_W
    groups, warnings = plan(W, H, template, row)

    for g in groups:
        placed, halo = g["placed"], g["halo"]
        if halo > 0:  # мягкая белая подложка: приглушает водяной знак только под текстом
            mask = Image.new("L", im.size, 0)
            md = ImageDraw.Draw(mask)
            pad = round(16 * scale)
            for b, r, x, yy, w in placed:
                bb = r["bbox"]
                md.rounded_rectangle(
                    (x + bb[0] - pad, yy - pad * 0.6, x + bb[0] + w + pad, yy + r["h"] + pad * 0.6),
                    radius=pad, fill=min(255, halo))
            mask = mask.filter(ImageFilter.GaussianBlur(max(1, round(14 * scale))))
            im.paste((255, 255, 255), mask=mask)

        draw = ImageDraw.Draw(im)
        for b, r, x, yy, w in placed:
            f = load_font(b["family"], b["bold"], r["size"])
            sx = r.get("sx", 1.0)
            if abs(sx - 1.0) > 0.005:
                bb = r["bbox"]
                bw, bh = max(1, math.ceil(bb[2] - bb[0])), max(1, math.ceil(bb[3] - bb[1]))
                layer = Image.new("L", (bw, bh), 0)
                ImageDraw.Draw(layer).multiline_text((-bb[0], -bb[1]), r["value"], font=f, fill=255,
                                                     spacing=b["spacing"], align=b["align"])
                layer = layer.resize((max(1, round(bw * sx)), bh), Image.LANCZOS)
                im.paste(b["color"], (round(x + bb[0]), round(yy)), layer)
                continue
            draw.multiline_text((x, yy - r["bbox"][1]), r["value"], font=f, fill=b["color"],
                                spacing=b["spacing"], align=b["align"])
    return im, warnings


def has_errors(warnings: list) -> bool:
    return any(w.get("level") == "error" for w in warnings)