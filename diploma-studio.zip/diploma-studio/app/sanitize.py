# -*- coding: utf-8 -*-
"""Строгая проверка и нормализация описания проекта, пришедшего от клиента.

Любое некорректное значение даёт понятную ошибку 400, а числа приводятся к безопасным
пределам — иначе один маленький запрос мог бы занять сервер на десятки секунд.
"""
from __future__ import annotations

import math
import re

from . import engine

MAX_ROWS = 5000
MAX_TEMPLATES = 20
MAX_GROUPS = 30
MAX_FIELDS = 30
MAX_CELL = 2000

_ID = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_COLOR = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


class ProjectError(ValueError):
    pass


def _str(v, maxlen=200, default=""):
    if v is None:
        return default
    if isinstance(v, bool) or not isinstance(v, (str, int, float)):
        raise ProjectError("Некорректное описание проекта: ожидалась строка")
    return engine.clean(v)[:maxlen]


def _num(v, lo, hi, default):
    if v is None or isinstance(v, bool):
        return default
    try:
        x = float(v)
    except (TypeError, ValueError):
        raise ProjectError("Некорректное описание проекта: ожидалось число")
    if not math.isfinite(x):
        return default
    return max(lo, min(hi, x))


def _list(v, maxlen, what):
    if v is None:
        return []
    if not isinstance(v, list):
        raise ProjectError(f"Некорректное описание проекта: {what} должны быть списком")
    if len(v) > maxlen:
        raise ProjectError(f"Слишком много элементов ({what}): максимум {maxlen}")
    return v


def _dict(v, what):
    if not isinstance(v, dict):
        raise ProjectError(f"Некорректное описание проекта: {what} должны быть объектом")
    return v


def _field(f):
    f = _dict(f, "поле")
    src = f.get("source") if isinstance(f.get("source"), dict) else {}
    if src.get("type") == "text":
        source = {"type": "text", "value": _str(src.get("value"), MAX_CELL)}
    else:
        cols = [_str(c) for c in _list(src.get("columns"), 20, "колонки поля")]
        source = {"type": "column", "columns": cols, "join": _str(src.get("join", "\n"), 10, "\n") or "\n"}
    font = f.get("font") if isinstance(f.get("font"), dict) else {}
    family = font.get("family")
    color = font.get("color")
    size_max = _num(f.get("size_max"), 1, 600, 40)
    size_min = _num(f.get("size_min"), 1, 600, 12)
    hp = f.get("max_height_pct")
    return {
        "id": _str(f.get("id"), 64), "name": _str(f.get("name")),
        "source": source,
        "part": f.get("part") if f.get("part") in ("all", "surname", "given") else "all",
        "transform": f.get("transform") if f.get("transform") in ("none", "upper", "lower", "title") else "none",
        "font": {
            "family": family if family in engine.FONT_FAMILIES else engine.DEFAULT_FAMILY,
            "bold": bool(font.get("bold", True)),
            "color": color if isinstance(color, str) and _COLOR.match(color) else "#000000",
        },
        "size_max": max(size_max, size_min), "size_min": size_min,
        "line_gap": _num(f.get("line_gap"), 0, 300, 4),
        "gap_after": _num(f.get("gap_after"), 0, 2000, 0),
        "align": f.get("align") if f.get("align") in ("center", "left", "right") else "center",
        "fill": bool(f.get("fill")),
        "stretch_x": bool(f.get("stretch_x")),
        "max_height_pct": None if not hp else _num(hp, 1, 100, None),
        "required": bool(f.get("required")),
    }


def _group(g):
    g = _dict(g, "группа")
    zone = g.get("zone")
    if not (isinstance(zone, list) and len(zone) == 4):
        raise ProjectError("Некорректное описание проекта: у группы полей нет зоны из 4 чисел")
    return {
        "id": _str(g.get("id"), 64), "name": _str(g.get("name")),
        "zone": [_num(z, -1e6, 1e6, 0) for z in zone],
        "valign": _num(g.get("valign"), 0, 1, 0.5),
        "halo": int(_num(g.get("halo"), 0, 255, 0)),
        "fields": [_field(f) for f in _list(g.get("fields"), MAX_FIELDS, "поля группы")],
    }


def _template(t):
    t = _dict(t, "шаблон")
    tid = t.get("id")
    if not isinstance(tid, str) or not _ID.match(tid):
        raise ProjectError("Некорректное описание проекта: у шаблона неверный идентификатор")
    return {
        "id": tid, "name": _str(t.get("name")) or "Шаблон",
        "match": [_str(m) for m in _list(t.get("match"), 50, "значения сопоставления")],
        "w": int(_num(t.get("w"), 0, 20000, 0)), "h": int(_num(t.get("h"), 0, 20000, 0)),
        "groups": [_group(g) for g in _list(t.get("groups"), MAX_GROUPS, "группы")],
    }


def sanitize_project(raw, max_rows: int = MAX_ROWS) -> dict:
    project = _dict(raw, "проект")
    rows_raw = _list(project.get("rows"), max_rows, "строки")
    rows = []
    for r in rows_raw:
        r = _dict(r, "строка")
        if len(r) > 300:
            raise ProjectError("В строке слишком много колонок")
        rows.append({_str(k): _str(v, MAX_CELL) for k, v in r.items()})
    match_col = project.get("match_column")
    columns = [_str(c) for c in _list(project.get("columns"), 300, "колонки")]
    return {
        "columns": [c for c in columns if c],
        "name": _str(project.get("name")) or "project",
        "filename_pattern": _str(project.get("filename_pattern")) or "{n}",
        "match_column": _str(match_col) if match_col else None,
        "templates": [_template(t) for t in _list(project.get("templates"), MAX_TEMPLATES, "шаблоны")],
        "rows": rows,
    }