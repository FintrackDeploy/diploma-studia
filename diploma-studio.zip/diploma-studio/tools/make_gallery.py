"""Рисует четыре готовых бланка (app/gallery/*.png) — чистые шаблоны без готового текста.

Запуск из корня проекта:  python tools/make_gallery.py

На бланке только оформление: гравированная рамка, розетка-гильош, заголовок типа документа, разделитель
и пустое поле. Всё, что вставляется из таблицы (организация, ФИО, должность, номинация, дата),
добавляется пользователем через «области текста». Зоны в app/gallery/gallery.json рассчитаны под эту раскладку:
  герб (y=190) → заголовок → разделитель (y=490) → «награждается» (y=555) → зона текста (108…946 × 610…1010)
  → разделитель (y=1050) → печать (y=1190) → пустые линии подписи (y=1318).
"""
import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
FONTS = ROOT / "app" / "fonts"
OUT = ROOT / "app" / "gallery"
W, H, S = 1054, 1492, 3          # размер бланка и коэффициент суперсэмплинга
GOLD = "#b8922f"
CX = W // 2


def font(style, size):
    name = {"b": "LiberationSerif-Bold.ttf", "i": "LiberationSerif-Italic.ttf", "r": "LiberationSerif-Regular.ttf"}[style]
    return ImageFont.truetype(str(FONTS / name), int(size * S))


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    """Смесь цветов: t=0 → a, t=1 → b."""
    a, b = rgb(a), rgb(b)
    return "#%02x%02x%02x" % tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gcd(a, b):
    return b and gcd(b, a % b) or a


class Canvas:
    def __init__(self, bg):
        self.bg = bg
        self.im = Image.new("RGB", (W * S, H * S), bg)
        self.d = ImageDraw.Draw(self.im)

    # --- примитивы (координаты в «бланковых» пикселях)
    def rect(self, x0, y0, x1, y1, **kw):
        self.d.rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], **kw)

    def frame(self, x0, y0, x1, y1, width, color):
        self.d.rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], outline=color, width=max(1, int(width * S)))

    def line(self, x0, y0, x1, y1, color, width=2):
        self.d.line([x0 * S, y0 * S, x1 * S, y1 * S], fill=color, width=max(1, int(width * S)))

    def poly(self, pts, color, width=1.2):
        self.d.line([(x * S, y * S) for x, y in pts], fill=color, width=max(1, int(width * S)), joint="curve")

    def circle(self, cx, cy, r, **kw):
        self.d.ellipse([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], **kw)

    def text(self, cx, y, s, f, color, anchor="mm"):
        self.d.text((cx * S, y * S), s, font=f, fill=color, anchor=anchor)

    def spaced(self, cx, cy, s, f, color, spacing):
        """Текст с разрядкой, по центру."""
        widths = [f.getlength(ch) / S for ch in s]
        total = sum(widths) + spacing * (len(s) - 1)
        x = cx - total / 2
        for ch, w in zip(s, widths):
            self.d.text((x * S, cy * S), ch, font=f, fill=color, anchor="lm")
            x += w + spacing
        return total

    def spaced_width(self, s, f, spacing):
        return sum(f.getlength(ch) / S for ch in s) + spacing * (len(s) - 1)

    def fit_spaced(self, s, size, max_w, spacing_ratio=0.1):
        while size > 12:
            f = font("b", size)
            if self.spaced_width(s, f, size * spacing_ratio) <= max_w:
                return f, size * spacing_ratio
            size -= 1
        return font("b", 12), 1

    # --- гильош
    def rosette(self, cx, cy, size, color, layers=3, R=100, r=37, d=62, step=6, width=1.0):
        k = (R - r) / r
        reach = (R - r) + d + step * layers
        scale = (size / 2) / reach
        turns = r // gcd(R, r)
        n = int(turns * 90)
        for layer in range(layers):
            dd = d + layer * step
            pts = []
            for i in range(n + 1):
                t = i / n * math.pi * 2 * turns
                x = ((R - r) * math.cos(t) + dd * math.cos(k * t)) * scale + cx
                y = ((R - r) * math.sin(t) - dd * math.sin(k * t)) * scale + cy
                pts.append((x, y))
            self.poly(pts, color, width)

    def diamond(self, cx, cy, r, color):
        self.d.polygon([(cx * S, (cy - r) * S), ((cx + r) * S, cy * S), (cx * S, (cy + r) * S), ((cx - r) * S, cy * S)], fill=color)

    def divider(self, y, color, half=250, gap=30):
        self.line(CX - half, y, CX - gap, y, GOLD, 2)
        self.line(CX + gap, y, CX + half, y, GOLD, 2)
        self.diamond(CX, y, 8, color)
        for dx in (-19, 19):
            self.circle(CX + dx, y, 2.6, fill=GOLD)

    def seal(self, cx, cy, color, r=52):
        n = 28
        pts = []
        for i in range(n * 2):
            a = math.pi * i / n
            rr = r if i % 2 == 0 else r - 5
            pts.append(((cx + rr * math.cos(a)) * S, (cy + rr * math.sin(a)) * S))
        self.d.polygon(pts, fill=GOLD)
        self.circle(cx, cy, r - 9, fill=color)
        self.circle(cx, cy, r - 17, outline=GOLD, width=int(1.8 * S))
        sp = []
        for i in range(10):
            a = -math.pi / 2 + math.pi * i / 5
            rr = 15 if i % 2 == 0 else 6.3
            sp.append(((cx + rr * math.cos(a)) * S, (cy + rr * math.sin(a)) * S))
        self.d.polygon(sp, fill=GOLD)

    def save(self, name):
        self.im.resize((W, H), Image.LANCZOS).save(OUT / name, optimize=True)


def wave_edge(c, horizontal, fixed, a, b, color, amp=6.0, period=34.0):
    """Две пересекающиеся синусоиды вдоль стороны рамки — «банкнотная» лента."""
    for phase in (0.0, math.pi):
        pts = []
        steps = int((b - a) * 3)
        for i in range(steps + 1):
            t = a + (b - a) * i / steps
            off = amp * math.sin((t - a) / period * math.pi * 2 + phase)
            pts.append((t, fixed + off) if horizontal else (fixed + off, t))
        c.poly(pts, color, 1.3)


def build(name, bg, color, title, cert=False):
    c = Canvas(bg)
    soft = mix(color, bg, 0.55)      # тон «гравировки»
    faint = mix(color, bg, 0.90)     # водяной знак

    # --- водяной знак под всем остальным
    c.rosette(CX, 790, 700, faint, layers=5, R=100, r=37, d=60, step=6, width=1.1)

    # --- рамка: толстая линия, тонкая, волновая лента, тонкая внутренняя
    c.frame(44, 44, W - 44, H - 44, 6, color)
    c.frame(58, 58, W - 58, H - 58, 1.5, GOLD)
    L, T, R_, B = 76, 76, W - 76, H - 76          # центры ленты
    m = 48                                         # отступ от углов под розетки
    wave_edge(c, True, T, L + m, R_ - m, soft)
    wave_edge(c, True, B, L + m, R_ - m, soft)
    wave_edge(c, False, L, T + m, B - m, soft)
    wave_edge(c, False, R_, T + m, B - m, soft)
    c.frame(94, 94, W - 94, H - 94, 1.5, color)
    for x, y in ((L, T), (R_, T), (L, B), (R_, B)):
        c.circle(x, y, 33, fill=bg, outline=color, width=int(1.6 * S))
        c.circle(x, y, 25, outline=soft, width=int(1.2 * S))
        c.circle(x, y, 17, outline=GOLD, width=int(1.4 * S))
        c.diamond(x, y, 9, color)
        c.circle(x, y, 3, fill=GOLD)

    # --- герб над заголовком (вместо названия организации)
    c.circle(CX, 196, 56, outline=GOLD, width=int(1.6 * S))
    c.circle(CX, 196, 50, fill=bg, outline=soft, width=int(1.2 * S))
    c.rosette(CX, 196, 92, color, layers=3, R=100, r=37, d=55, step=6, width=0.9)
    c.circle(CX, 196, 12, fill=color)
    c.circle(CX, 196, 5, fill=GOLD)

    # --- заголовок типа документа (с разрядкой)
    if len(title) == 1:
        f, sp = c.fit_spaced(title[0], 104, 700)
        c.spaced(CX, 340, title[0], f, color, sp)
    else:
        f, sp = c.fit_spaced(max(title, key=len), 84, 700)
        c.spaced(CX, 318, title[0], f, color, sp)
        c.spaced(CX, 410, title[1], f, color, sp)
    c.divider(490, color)
    c.text(CX, 556, "награждается в номинации" if cert else "награждается", font("i", 38), color)

    # --- нижняя часть: разделитель, печать, пустые линии для подписей
    c.divider(1050, color)
    c.seal(CX, 1190, color)
    for x0, x1 in ((160, 400), (654, 894)):
        c.line(x0, 1322, x1, 1322, soft, 1.6)
    c.save(name)


build("pochetnaya.png", "#fffcf4", "#7b1f2e", ["ПОЧЁТНАЯ", "ГРАМОТА"])
build("gramota.png", "#fdfdfa", "#1f3a6e", ["ГРАМОТА"])
build("blag.png", "#fcfdf9", "#1f5e4b", ["БЛАГОДАРСТВЕННОЕ", "ПИСЬМО"])
build("sertifikat.png", "#fafdfd", "#0f5c6e", ["СЕРТИФИКАТ"], cert=True)
print("ok")
