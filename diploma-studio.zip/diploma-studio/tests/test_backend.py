# -*- coding: utf-8 -*-
import copy
import io
import json
import re
import time
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from PIL import Image

from app import engine
from app.main import app

client = TestClient(app)
GAL = Path(__file__).resolve().parents[1] / "app" / "gallery"
SET = client.get("/api/gallery").json()[0]  # набор из четырёх типов


def tpl_files(templates=None):
    return [("template_files", (t["id"] + ".png", (GAL / t["image"]).read_bytes(), "image/png"))
            for t in (templates or SET["templates"])]


def project(rows=None, **kw):
    p = {"name": "Тест", "templates": [copy.deepcopy({k: v for k, v in t.items() if k != "image"}) for t in SET["templates"]],
         "rows": copy.deepcopy(rows if rows is not None else SET["rows"]), "match_column": "Тип диплома", "filename_pattern": "{ФИО}"}
    p.update(kw)
    return p


def post(path, proj, files=None, **data):
    body = json.dumps(proj, ensure_ascii=False).encode()
    return client.post(path, files=[("project", ("project.json", body, "application/json")), *(files if files is not None else tpl_files())],
                       data=data)


# ------------------------------------------------------------------ движок

@pytest.mark.parametrize("fio,expected", [
    ("Иванов Иван Иванович", ("Иванов", "Иван Иванович")),
    ("Иван Иванович Иванов", ("Иванов", "Иван Иванович")),
    ("Мария Ивановна Петрова", ("Петрова", "Мария Ивановна")),
    ("Иванов Иван", ("Иванов", "Иван")),
    ("Петров-Водкин Кузьма Сергеевич", ("Петров-Водкин", "Кузьма Сергеевич")),
    ("Сидорович Мария Александровна", ("Сидорович", "Мария Александровна")),
    ("Ковальчук Елена Владимировна", ("Ковальчук", "Елена Владимировна")),
    # фамилии на -ович/-евич не должны ломать порядок «Имя Отчество Фамилия»
    ("Иван Петрович Адамович", ("Адамович", "Иван Петрович")),
    ("Анна Сергеевна Ковалевич", ("Ковалевич", "Анна Сергеевна")),
    ("Адамович Иван Петрович", ("Адамович", "Иван Петрович")),
    ("Ковалевич Анна Сергеевна", ("Ковалевич", "Анна Сергеевна")),
    ("Гусейнов Эльнур Тофик оглы", ("Гусейнов", "Эльнур Тофик оглы")),
])
def test_split_fio(fio, expected):
    assert engine.split_fio(fio) == expected


def test_pick_template_is_exact_only():
    T = [{"id": "a", "name": "Диплом I степени"}, {"id": "b", "name": "Диплом II степени"}]
    assert engine.pick_template(T, "Тип", {"Тип": " диплом  ii степени. "})[0]["id"] == "b"
    for bad in ("Диплом III степени", "Диплом 3 степени"):
        tpl, err = engine.pick_template(T, "Тип", {"Тип": bad})
        assert tpl is None and "неизвестное значение" in err


def test_multiple_templates_need_match_column():
    T = [{"id": "a", "name": "A"}, {"id": "b", "name": "B"}]
    tpl, err = engine.pick_template(T, None, {})
    assert tpl is None and "не выбрана колонка" in err


def test_excel_dates_are_readable():
    import datetime
    assert engine.clean(datetime.datetime(2026, 5, 30)) == "30.05.2026"


# ------------------------------------------------------------------ API

def test_zip_and_pdf_roundtrip():
    r = post("/api/generate/zip", project(), start=1)
    assert r.status_code == 200 and r.headers["X-Problem-Rows"] == "0"
    z = zipfile.ZipFile(io.BytesIO(r.content))
    assert len(z.namelist()) == 4 and all(re.fullmatch(r"\d{5}__.+\.png", n) for n in z.namelist())
    r = post("/api/generate/pdf", project())
    assert r.status_code == 200 and r.content.startswith(b"%PDF")


def test_batch_numbering_uses_start():
    p = project(rows=SET["rows"][:2], filename_pattern="{n}")
    z = zipfile.ZipFile(io.BytesIO(post("/api/generate/zip", p, start=101).content))
    assert sorted(z.namelist()) == ["00101__101.png", "00102__102.png"]


def test_large_project_over_1mib_is_accepted():
    """Раньше больше ~2500 строк давали «Part exceeded maximum size of 1024KB»."""
    row = dict(SET["rows"][0])
    r = post("/api/render/preview", project(rows=[row]))
    assert r.status_code == 200
    big = project(rows=[row] * 500)
    assert len(json.dumps(big)) < 1_000_000
    # 5000 строк уходят на проверку обычным JSON без multipart-лимита
    v = client.post("/api/validate", json=project(rows=[row] * 5000))
    assert v.status_code == 200 and v.json()["total_rows"] == 5000 and v.json()["problems"] == []


def test_batch_row_limit():
    r = post("/api/generate/zip", project(rows=[SET["rows"][0]] * 501))
    assert r.status_code == 400 and "максимум" in r.json()["detail"]


def test_pdf_page_is_a4_regardless_of_pixels():
    t = copy.deepcopy(project()["templates"][1]); t["w"], t["h"] = 2480, 3508
    b = io.BytesIO(); Image.new("RGB", (2480, 3508), (250, 248, 240)).save(b, "PNG")
    p = project(rows=[SET["rows"][1]], templates=[t], match_column=None)
    r = post("/api/generate/pdf", p, files=[("template_files", (t["id"] + ".png", b.getvalue(), "image/png"))])
    w, h = map(float, re.search(rb"/MediaBox \[ ?0 0 ([\d.]+) ([\d.]+)", r.content).groups())
    assert abs(w / 72 * 25.4 - 210) < 1 and abs(h / 72 * 25.4 - 297) < 1


def test_hostile_values_are_400_not_500_and_fast():
    def mut(fn):
        p = project(rows=[SET["rows"][1]]); fn(p); return p
    cases = {
        "templates str": lambda p: p.__setitem__("templates", ["oops"]),
        "rows str": lambda p: p.__setitem__("rows", "abc"),
        "zone bad": lambda p: p["templates"][1]["groups"][0].__setitem__("zone", ["a", 1, 2, 3]),
        "fields null->ok": lambda p: p["templates"][1]["groups"][0].__setitem__("fields", None),
        "bad id": lambda p: p["templates"][1].__setitem__("id", "../x"),
    }
    for name, fn in cases.items():
        t0 = time.time()
        r = post("/api/render/preview", mut(fn))
        assert r.status_code in (200, 400), (name, r.status_code)
        assert time.time() - t0 < 5, name


def test_huge_font_is_clamped_and_fast():
    p = project(rows=[SET["rows"][1]])
    p["templates"][1]["groups"][0]["fields"][0]["size_max"] = 8000
    t0 = time.time()
    assert post("/api/render/preview", p).status_code == 200
    assert time.time() - t0 < 5   # раньше 42 секунды


def test_image_bomb_rejected():
    b = io.BytesIO(); Image.new("1", (12000, 12000)).save(b, "PNG")  # 144 Мпикс
    t = project()["templates"][1]
    p = project(rows=[SET["rows"][1]], templates=[t], match_column=None)
    r = post("/api/render/preview", p, files=[("template_files", (t["id"] + ".png", b.getvalue(), "image/png"))])
    assert r.status_code == 400


def test_validate_finds_overflow_and_wrong_type():
    rows = [dict(SET["rows"][0]), dict(SET["rows"][1]), dict(SET["rows"][2])]
    rows[0]["ФИО"] = "Очень-Очень-Длинная " * 60
    rows[1]["Тип диплома"] = "Грамота III степени"
    v = client.post("/api/validate", json=project(rows=rows)).json()
    msgs = {p["row"]: p["msg"] for p in v["problems"]}
    assert "не помещается" in msgs[0] and "неизвестное значение" in msgs[1] and 2 not in msgs


def test_validate_flags_missing_match_column():
    v = client.post("/api/validate", json=project(match_column=None)).json()
    assert len(v["problems"]) == 4 and "не выбрана колонка" in v["problems"][0]["msg"]


def test_excel_duplicates_and_dates():
    import datetime
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active
    ws.append(["ФИО", "Дата", "Дата"]); ws.append(["Иванов И.И.", datetime.date(2026, 5, 30), "второй"])
    b = io.BytesIO(); wb.save(b)
    j = client.post("/api/parse-excel", files={"file": ("a.xlsx", b.getvalue())}).json()
    assert j["columns"] == ["ФИО", "Дата", "Дата (2)"]
    assert j["rows"][0] == {"ФИО": "Иванов И.И.", "Дата": "30.05.2026", "Дата (2)": "второй"}


def test_cache_headers():
    assert client.get("/app.js").headers["cache-control"] == "no-cache"
    assert client.get("/tokens.css").headers["cache-control"] == "no-cache"
    assert "no-cache" in client.get("/gallery-files/blag.png").headers["cache-control"]


def test_event_loop_not_blocked_by_generation():
    """Пока идёт тяжёлая генерация, лёгкие запросы должны отвечать быстро."""
    import threading
    p = project(rows=[SET["rows"][1]] * 60, match_column=None)
    p["templates"] = p["templates"][:1]
    done = {}

    def heavy():
        done["r"] = post("/api/generate/zip", p, files=tpl_files(SET["templates"][:1]))

    th = threading.Thread(target=heavy); th.start(); time.sleep(0.4)
    # TestClient выполняет приложение в отдельном потоке-портале; достаточно, что лёгкий запрос не ждёт всю генерацию
    t0 = time.time(); client.get("/api/limits"); light = time.time() - t0
    th.join()
    assert done["r"].status_code == 200 and light < 1.5


# ------------------------------------------------------------------ исправления после аудита

import app.main as main_mod  # noqa: E402


def test_healthz_and_security_headers():
    r = client.get("/healthz")
    assert r.status_code == 200 and r.json() == {"ok": True}
    csp = r.headers["content-security-policy"]
    assert "default-src 'self'" in csp and "frame-ancestors 'none'" in csp and "unsafe-eval" not in csp
    assert r.headers["x-frame-options"] == "DENY"


def test_preview_decodes_only_used_template():
    """Файлы неиспользуемых шаблонов не требуются и не декодируются."""
    p = project(rows=[SET["rows"][0]])
    first = [t for t in SET["templates"] if t["name"] == SET["rows"][0]["Тип диплома"]][0]
    assert post("/api/render/preview", p, files=tpl_files([first])).status_code == 200


def test_missing_file_of_used_template_is_400():
    r = post("/api/render/preview", project(rows=[SET["rows"][0]]), files=[])
    assert r.status_code == 400 and "Не найден файл шаблона" in r.json()["detail"]


def test_template_limit_is_25_megapixels_and_header_checked():
    b = io.BytesIO(); Image.new("1", (5100, 5100)).save(b, "PNG")        # 26 Мпикс
    t = project()["templates"][1]
    p = project(rows=[SET["rows"][1]], templates=[t], match_column=None)
    r = post("/api/render/preview", p, files=[("template_files", (t["id"] + ".png", b.getvalue(), "image/png"))])
    assert r.status_code == 400 and "слишком большой" in r.json()["detail"]


def test_only_png_and_jpeg_templates():
    b = io.BytesIO(); Image.new("RGB", (50, 50)).save(b, "GIF")
    t = project()["templates"][1]
    p = project(rows=[SET["rows"][1]], templates=[t], match_column=None)
    r = post("/api/render/preview", p, files=[("template_files", (t["id"] + ".png", b.getvalue(), "image/png"))])
    assert r.status_code == 400


def test_transparent_png_is_flattened_on_white():
    b = io.BytesIO(); Image.new("RGBA", (400, 560), (0, 0, 0, 0)).save(b, "PNG")
    t = copy.deepcopy(project()["templates"][1]); t["w"], t["h"] = 400, 560
    for g in t["groups"]:
        g["zone"] = [0, 0, 1, 1]
    row = dict(SET["rows"][1]); row["ФИО"] = ""
    p = project(rows=[row], templates=[t], match_column=None)
    r = post("/api/render/preview", p, files=[("template_files", (t["id"] + ".png", b.getvalue(), "image/png"))])
    px = Image.open(io.BytesIO(r.content)).convert("RGB").getpixel((350, 500))
    assert min(px) > 240, px        # прозрачность стала белой, а не чёрной


def test_zip_keeps_row_order_with_mixed_templates():
    """Рендер группируется по шаблону, но порядок файлов должен остаться исходным."""
    order = [0, 1, 2, 3, 2, 1, 0, 3]
    rows = [dict(SET["rows"][i], ФИО=f"Иванов Иван {k}") for k, i in enumerate(order)]
    r = post("/api/generate/zip", project(rows=rows, filename_pattern="{n}"), start=1)
    z = zipfile.ZipFile(io.BytesIO(r.content))
    assert z.namelist() == [f"{n:05d}__{n:03d}.png" for n in range(1, 9)]
    proj = main_mod.parse_project(json.dumps(project(rows=rows)).encode())
    for k, name in enumerate(z.namelist()):
        tpl = main_mod.row_template(proj, proj["rows"][k])
        base = main_mod.load_template_image((GAL / next(t["image"] for t in SET["templates"] if t["id"] == tpl["id"])).read_bytes(), tpl)
        expected, _ = engine.render(base, tpl, proj["rows"][k])
        got = Image.open(io.BytesIO(z.read(name))).convert("RGB")
        assert got.tobytes() == expected.tobytes(), name


def test_validate_reports_renamed_column(monkeypatch):
    """Колонка переименована, а поля шаблона остались прежними — раньше это молча давало пустые поля."""
    p = project(rows=[{("ФИО2" if k == "ФИО" else k): v for k, v in SET["rows"][0].items()}],
                columns=["ФИО2", "Должность", "ГУО", "Тип диплома", "Номинация"])
    v = client.post("/api/validate", json=p).json()
    assert any("нет колонки «ФИО»" in m for m in v["config_errors"]), v
    p2 = project(columns=[*SET["columns"]])
    assert client.post("/api/validate", json=p2).json()["config_errors"] == []
    p3 = project(match_column="Нет такой", columns=[*SET["columns"]])
    assert any("не найдена в таблице" in m for m in client.post("/api/validate", json=p3).json()["config_errors"])


def test_validate_body_over_limit_is_413_without_reading():
    r = client.post("/api/validate", content=b"x" * (main_mod.MAX_VALIDATE_BODY + 1),
                    headers={"content-type": "application/json"})
    assert r.status_code == 413


def test_rate_limit_returns_429(monkeypatch):
    monkeypatch.setattr(main_mod, "RATE_LIMIT", 5)
    main_mod._HITS.clear()
    codes = [client.get("/api/limits").status_code for _ in range(8)]
    assert codes[:5] == [200] * 5 and set(codes[5:]) == {429}
    main_mod._HITS.clear()


def test_queue_overflow_is_503_not_memory_growth(monkeypatch):
    monkeypatch.setattr(main_mod, "_inflight", main_mod.MAX_JOBS + main_mod.MAX_QUEUE)
    r = post("/api/render/preview", project(rows=[SET["rows"][0]]))
    assert r.status_code == 503 and r.headers["retry-after"]


def test_xlsx_zip_bomb_rejected():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", "<Types/>")
        zf.writestr("xl/worksheets/sheet1.xml", b"0" * (main_mod.MAX_XLSX_UNPACKED + 10 * 1024 * 1024))
    assert len(buf.getvalue()) < 5 * 1024 * 1024
    r = client.post("/api/parse-excel", files={"file": ("bomb.xlsx", buf.getvalue())})
    assert r.status_code == 400 and "слишком большой" in r.json()["detail"]


def test_not_a_zip_is_400():
    r = client.post("/api/parse-excel", files={"file": ("a.xlsx", b"hello")})
    assert r.status_code == 400


def test_filenames_windows_safe():
    assert engine.safe_filename("CON") == "_CON"
    assert engine.safe_filename("nul.txt") == "_nul.txt"
    assert engine.safe_filename("Иван\u0301") == engine.safe_filename("Ива\u043d\u0301")   # NFC
    assert engine.safe_filename("a/b:c*") == "a_b_c_"


def test_unhandled_error_is_500_json_without_details(monkeypatch):
    def boom(*a, **k):
        raise RuntimeError("секрет Иванов Иван")
    monkeypatch.setattr(main_mod, "_validate", boom)
    c2 = TestClient(app, raise_server_exceptions=False)
    r = c2.post("/api/validate", json=project())
    assert r.status_code == 500 and "Иванов" not in r.text
