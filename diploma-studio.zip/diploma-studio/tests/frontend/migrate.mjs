import "fake-indexeddb/auto";
import assert from "node:assert/strict";
// 1) создаём БД версии 1 в старом формате (картинка base64 внутри проекта)
const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");
await new Promise((res, rej) => {
  const r = indexedDB.open("diploma-studio", 1);
  r.onupgradeneeded = () => r.result.createObjectStore("projects", { keyPath: "id" });
  r.onsuccess = () => {
    const t = r.result.transaction("projects", "readwrite");
    t.objectStore("projects").put({ id: "old1", name: "Старый", rows: [{a:"1"}], columns:["a"], templates: [{ id: "t1", name: "T", w:1,h:1, groups: [], image_data: "data:image/png;base64," + png.toString("base64") }] });
    t.oncomplete = () => { r.result.close(); res(); };
  };
  r.onerror = () => rej(r.error);
});
const store = await import("../../app/static/store.js");
const p = await store.getProject("old1");
assert.equal(p.templates[0].image_data, undefined, "image_data должен быть удалён");
const blob = await store.getImage("old1", "t1");
assert.ok(blob && blob.size === png.length, "картинка перенесена в отдельное хранилище");
assert.equal(p.rows.length, 1);
console.log("миграция v1→v2: OK (картинка", blob.size, "байт перенесена в Blob)");
await store.deleteProject("old1");
assert.equal(await store.getImage("old1", "t1"), null);
console.log("удаление проекта чистит и картинки: OK");
