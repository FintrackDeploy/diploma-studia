import "fake-indexeddb/auto";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
globalThis.JSZip = require("jszip");
globalThis.PDFLib = require("pdf-lib");
globalThis.API_BASE = process.env.API_BASE || "http://127.0.0.1:8021";
globalThis.FileReader = class { readAsDataURL(b) { b.arrayBuffer().then((ab) => { this.result = `data:${b.type || "application/octet-stream"};base64,` + Buffer.from(ab).toString("base64"); this.onload(); }, (e) => { this.error = e; this.onerror(); }); } };
let saved = null;   // заглушка document для saveBlob
globalThis.document = { createElement: () => ({ click() { saved.clicked = true; }, remove() {} }), body: { appendChild(a) { saved = { a }; } } };

const { api, LIMITS, pickTemplate } = await import("../../app/static/api.js");

// --- проект из галереи (набор из 4 типов)
const p = await api.projectFromGallery("set");
const full = await api.getProject(p.id);
assert.equal(full.templates.length, 4);
assert.ok(full.templates.every((t) => t._blob && t._url), "картинки подгружены");
console.log("галерея → IndexedDB → hydrate: OK");

// --- гонка записей: одновременные setRows / updateTemplate / updateProject не должны терять данные
const rows = Array.from({ length: 7 }, (_, i) => ({ ...full.rows[i % 4], "ФИО": `Иванов Иван ${i}` }));
await Promise.all([
  api.setRows(p.id, full.columns, rows),
  api.updateTemplate(p.id, "t1", { name: "Почетная грамота (изм.)" }),
  api.updateProject(p.id, { filename_pattern: "{ФИО}" }),
  api.updateTemplate(p.id, "t2", { match: ["Грамота", "Gramota"] }),
]);
const after = await api.getProject(p.id);
assert.equal(after.rows.length, 7);
assert.equal(after.templates[0].name, "Почетная грамота (изм.)");
assert.deepEqual(after.templates[1].match, ["Грамота", "Gramota"]);
assert.equal(after.filename_pattern, "{ФИО}");
console.log("параллельные записи не затирают друг друга: OK");

// --- выбор шаблона на клиенте == серверному
assert.equal(pickTemplate(after, { "Тип диплома": " грамота " }).id, "t2");
assert.equal(pickTemplate(after, { "Тип диплома": "Грамота III степени" }), null);

// --- предпросмотр отправляет только нужный шаблон и работает
const res = await api.preview(p.id, 1);
assert.equal(res.status, 200); assert.ok((await res.arrayBuffer()).byteLength > 5000);
console.log("предпросмотр: OK");

// --- валидация (JSON без картинок)
const v = await api.validate(p.id);
assert.equal(v.total_rows, 7); assert.equal(v.problems.length, 0);

// --- пакетный ZIP: 7 строк по 3 в пачке → 3 запроса, сквозная нумерация, нет дублей имён
LIMITS.batchRows = 3; LIMITS.batchRowsLight = 3;
const seen = [];
const z = await api.generate(p.id, "zip", (d, t) => seen.push(d));
assert.equal(z.count, 1); assert.equal(z.files[0].filename, `${full.name}.zip`.replace(/[\\/:*?"<>|]+/g, "_"));
const zip = await JSZip.loadAsync(await z.files[0].blob.arrayBuffer());
const names = Object.keys(zip.files).sort();
assert.equal(names.length, 7); assert.equal(new Set(names).size, 7);
assert.deepEqual(seen.slice(-1), [7]); assert.ok(seen.length >= 3);
console.log("ZIP пачками (3+3+1):", names.length, "файлов, прогресс", seen.join("→"), "OK");

// --- дубликаты имён между пачками: все строки с одинаковым ФИО
await api.setRows(p.id, full.columns, Array.from({ length: 5 }, () => ({ ...full.rows[0] })));
const z2 = await JSZip.loadAsync(await (await api.generate(p.id, "zip")).files[0].blob.arrayBuffer());
assert.equal(Object.keys(z2.files).length, 5);
console.log("одинаковые имена в разных пачках получают суффиксы:", Object.keys(z2.files).join(", "));

// --- PDF: склейка пачек + деление на части
await api.setRows(p.id, full.columns, rows);
const pdf = await api.generate(p.id, "pdf");
const doc = await PDFLib.PDFDocument.load(await pdf.files[0].blob.arrayBuffer());
assert.equal(doc.getPageCount(), 7);
const { width, height } = doc.getPage(0).getSize();
assert.ok(Math.abs(width / 72 * 25.4 - 210) < 1 && Math.abs(height / 72 * 25.4 - 297) < 1);
console.log("PDF пачками: 7 страниц, страница", Math.round(width / 72 * 25.4) + "×" + Math.round(height / 72 * 25.4), "мм OK");
LIMITS.pdfPartPages = 3;
const parts = await api.generate(p.id, "pdf");
assert.equal(parts.count, 3);
assert.ok(parts.files.every((f, i) => f.filename.endsWith(`_часть${i + 1}.pdf`)));
const pageCounts = [];
for (const f of parts.files) pageCounts.push((await PDFLib.PDFDocument.load(await f.blob.arrayBuffer())).getPageCount());
assert.deepEqual(pageCounts, [3, 3, 1]);
LIMITS.pdfPartPages = 500;
console.log("PDF делится на части (3 отдельных PDF: 3+3+1 страниц): OK");

// --- проблемы в данных доходят до клиента
const bad = rows.map((r, i) => i === 2 ? { ...r, "ФИО": "Очень-Длинное ".repeat(80) } : r);
await api.setRows(p.id, full.columns, bad);
const zb = await api.generate(p.id, "zip");
assert.equal(zb.problems, 1);
const vb = await api.validate(p.id);
assert.equal(new Set(vb.problems.map((x) => x.row)).size, 1); assert.equal(vb.problems[0].row, 2);
console.log("переполнение текста находится проверкой и учитывается при генерации: OK");
await api.setRows(p.id, full.columns, rows);

// --- выдача файлов по частям с потоковой отдачей (память вкладки не растёт вместе с проектом)
LIMITS.partBytes = 1;                      // любая пачка превышает лимит → отдаём часть сразу
const got = [];
const zs = await api.generate(p.id, "zip", () => {}, async (f) => { got.push(f); });
assert.equal(zs.count, 3); assert.equal(zs.files.length, 0, "в режиме onFile ничего не копится");
assert.ok(got.every((f, i) => f.filename.endsWith(`_часть${i + 1}.zip`)));
const counts = [];
for (const f of got) counts.push(Object.keys((await JSZip.loadAsync(await f.blob.arrayBuffer())).files).length);
assert.deepEqual(counts, [3, 3, 1]);
LIMITS.partBytes = 150 * 1024 * 1024;
console.log("ZIP делится по размеру и отдаётся по мере готовности (3+3+1): OK");

// --- Windows/macOS не различают регистр: «Иванов» и «иванов» — разные файлы только по суффиксу
await api.setRows(p.id, full.columns, ["Иванов", "иванов", "ИВАНОВ"].map((f) => ({ ...full.rows[0], "ФИО": f })));
const savedPattern = (await api.getProject(p.id)).filename_pattern;
await api.updateProject(p.id, { filename_pattern: "{ФИО}" });
const zc = await JSZip.loadAsync(await (await api.generate(p.id, "zip")).files[0].blob.arrayBuffer());
const lower = Object.keys(zc.files).map((n) => n.toLowerCase());
assert.equal(lower.length, 3); assert.equal(new Set(lower).size, 3, "имена различаются без учёта регистра: " + lower.join(", "));
await api.updateProject(p.id, { filename_pattern: savedPattern });
await api.setRows(p.id, full.columns, rows);
console.log("имена файлов уникальны без учёта регистра:", Object.keys(zc.files).join(", "));

// --- повторы при временных ошибках сервера (429/503) и отказ после исчерпания попыток
globalThis.RETRY_DELAY_MS = 1;
const realFetch = globalThis.fetch;
let fails = 2, calls = 0;
globalThis.fetch = async (u, o) => {
  if (String(u).includes("/generate/zip")) { calls++; if (fails-- > 0) return new Response(JSON.stringify({ detail: "Сервер сейчас занят" }), { status: 503, headers: { "content-type": "application/json" } }); }
  return realFetch(u, o);
};
const retried = await api.generate(p.id, "zip");
assert.equal(retried.count, 1); assert.ok(calls >= 3, "было повторено: " + calls);
fails = 99;
await assert.rejects(() => api.generate(p.id, "zip"), /занят/);
globalThis.fetch = realFetch;
console.log("повторы при 503 и понятная ошибка после 4 попыток: OK");

// --- проверка пачками + кэш
LIMITS.validateChunk = 2;
let vcalls = 0;
globalThis.fetch = async (u, o) => { if (String(u).endsWith("/validate")) vcalls++; return realFetch(u, o); };
const badRows = rows.map((r, i) => i === 5 ? { ...r, "ФИО": "Очень-Длинное ".repeat(80) } : r);
await api.setRows(p.id, full.columns, badRows);
const v1 = await api.validate(p.id);
assert.equal(vcalls, 4, "7 строк по 2 → 4 запроса"); assert.equal(v1.total_rows, 7);
assert.deepEqual([...new Set(v1.problems.map((x) => x.row))], [5], "номер строки пересчитан с учётом смещения пачки");
await api.validate(p.id); assert.equal(vcalls, 4, "повторная проверка без изменений берётся из кэша");
await api.setRows(p.id, full.columns, rows);
const v2 = await api.validate(p.id); assert.equal(vcalls, 8); assert.equal(v2.problems.length, 0);
globalThis.fetch = realFetch; LIMITS.validateChunk = 500;
console.log("проверка пачками, смещение строк, кэш: OK");

// --- переименование колонки переносит привязки, а «ручная» поломка привязок обнаруживается
await api.renameColumn(p.id, "ФИО", "Получатель");
const ren = await api.getProject(p.id);
assert.ok(ren.columns.includes("Получатель") && !ren.columns.includes("ФИО"));
assert.ok(ren.rows.every((r) => "Получатель" in r && !("ФИО" in r)));
const cols = ren.templates.flatMap((t) => t.groups.flatMap((g) => g.fields.flatMap((f) => f.source.columns || [])));
assert.ok(cols.includes("Получатель") && !cols.includes("ФИО"), "поля шаблонов переведены на новую колонку");
assert.equal((await api.validate(p.id)).config_errors.length, 0);
// колонка пропала без переноса привязок (как раньше при ручном переименовании)
await api.setRows(p.id, ["Кто-то", ...ren.columns.filter((c) => c !== "Получатель")], ren.rows.map(({ "Получатель": x, ...r }) => ({ "Кто-то": x, ...r })));
const broken = await api.validate(p.id);
assert.ok(broken.config_errors.some((m) => m.includes("нет колонки «Получатель»")), JSON.stringify(broken.config_errors));
await api.renameColumn(p.id, "Кто-то", "ФИО");   // чистим состояние
console.log("переименование колонки переносит привязки; битые привязки видны в проверке: OK");

// --- проект изменён в другой вкладке: свои записи блокируются, а чужие мы видим
const q = await api.newProject("Двойная вкладка");
const other = new BroadcastChannel("diploma-studio");
const heard = [];
other.onmessage = (ev) => heard.push(ev.data);
await api.updateProject(q.id, { name: "Меняю в этой вкладке" });
await new Promise((r) => setTimeout(r, 80));
assert.ok(heard.some((m) => m.type === "changed" && m.id === q.id), "соседние вкладки узнают об изменении");
other.postMessage({ type: "changed", id: q.id });                   // «другая вкладка» записала проект
await new Promise((r) => setTimeout(r, 80));
await assert.rejects(() => api.updateProject(q.id, { name: "затру чужое" }), /другой вкладке/);
other.close();
console.log("защита от затирания при двух вкладках: OK");

// --- экспорт → импорт копии
await api.exportProject(p.id);
assert.ok(saved.clicked && saved.a.download.endsWith(".diploma.json"));

// href — blob: URL; в Node читаем через fetch не выйдет, поэтому повторяем экспорт вручную
const src = await api.getProject(p.id);
const rec = JSON.parse(JSON.stringify(src, (k, v) => (k.startsWith("_") ? undefined : v)));
const { blobToDataUrl } = await import("../../app/static/store.js");
for (const t of rec.templates) t.image_data = await blobToDataUrl(src.templates.find((x) => x.id === t.id)._blob);
const imported = await api.importProject({ text: async () => JSON.stringify(rec) });
assert.notEqual(imported.id, p.id);
const back = await api.getProject(imported.id);
assert.equal(back.templates.length, 4); assert.equal(back.rows.length, 7);
assert.ok(back.templates.every((t) => t._blob.size > 1000));
await assert.rejects(() => api.importProject({ text: async () => JSON.stringify({ templates: [{ id: "../x", image_data: "data:image/png;base64,AA==" }], rows: [] }) }), /повреждён/);
await assert.rejects(() => api.importProject({ text: async () => "не json" }), /повреждён/);
console.log("импорт копии + отклонение битых файлов: OK");

// --- список проектов (источник правды — IndexedDB) и удаление
const list = await api.listProjects();
assert.equal(list.length, 3);  // проект из галереи, «Двойная вкладка» и импортированная копия
await api.deleteProject(imported.id);
assert.equal((await api.listProjects()).length, 2);
console.log("список проектов из IndexedDB и удаление: OK");
process.exit(0);
